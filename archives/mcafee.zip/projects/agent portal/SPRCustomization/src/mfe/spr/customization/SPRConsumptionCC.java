package mfe.spr.customization;

import oracle.mds.core.MetadataObject;
import oracle.mds.core.RestrictedSession;
import oracle.mds.cust.CacheHint;
import oracle.mds.cust.CustomizationClass;

public class SPRConsumptionCC extends CustomizationClass {
    private static final String DEFAULT_LAYER_NAME = "spr";
    private String mLayerName = DEFAULT_LAYER_NAME;

    public SPRConsumptionCC() {
        super();
    }

    public CacheHint getCacheHint() {
        return CacheHint.ALL_USERS;
    }

    public String getName() {
        return mLayerName;
    }

    public String[] getValue(RestrictedSession restrictedSession,
                             MetadataObject metadataObject) {
        return new String[] { "consumption" };
    }
}
