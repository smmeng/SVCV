package mfe.spr.common.exceptions;

public class SPRApplicationException extends RuntimeException {
    @SuppressWarnings("compatibility:6154545913636654316")
    private static final long serialVersionUID = -5187610085125030396L;
    private String errorCode;

    public SPRApplicationException(String pErrorCode, String pMessage, Throwable pThrowable) {
        super(pMessage, pThrowable);
        errorCode = pErrorCode;
    }

    public SPRApplicationException(String pErrorCode, String pMessage) {
        this(pErrorCode, pMessage, null);
    }

    public String getErrorCode() {
        return errorCode;
    }
}
