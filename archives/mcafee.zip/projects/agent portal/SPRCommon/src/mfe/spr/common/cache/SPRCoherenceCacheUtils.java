package mfe.spr.common.cache;


import com.tangosol.net.CacheFactory;
import com.tangosol.net.NamedCache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mfe.spr.common.constants.SPRConstants;


public final class SPRCoherenceCacheUtils {
    private SPRCoherenceCacheUtils() {
        super();
    }

    public static NamedCache getLOVNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_LOV_CACHE);
    }

    public static synchronized void updateLOVCache(Object key, Object data) {
        getLOVNamedCache().put(key, data);
    }

    public static Object getLOVCache(Object key) {
        return getLOVNamedCache().get(key);
    }

    public static NamedCache getPropertyNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_PROPERTY_KEY);
    }

    public static String getProperty(String key) {
        return (String)getPropertyNamedCache().get(key);
    }

    public static NamedCache getGrantNumberNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_GRANTNUMBER_CACHE);
    }

    public static synchronized void updateGrantNumberCache(Object key, Object data) {
        getGrantNumberNamedCache().put(key, data);
    }

    public static Object getGrantNumberCache(Object key) {
        return getGrantNumberNamedCache().get(key);
    }

    public static NamedCache getRegionNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_COUNTRY_REGION_KEY);
    }

    public static synchronized void updateRegionCache(Object key, Object data) {
        getRegionNamedCache().put(key, data);
    }

    public static String getRegionCache(Object key) {
        return (String)getRegionNamedCache().get(key);
    }

    public static NamedCache getCountryNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_COUNTRY_KEY);
    }

    public static synchronized void updateCountryCache(Object key, Object data) {
        getCountryNamedCache().put(key, data);
    }

    public static HashMap getCountryCache(Object key) {
        return (HashMap)getCountryNamedCache().get(key);
    }

    public static NamedCache getStateCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_COUNTRY_STATE_KEY);
    }

    public static synchronized void updateStateCache(Object key, Object data) {
        getStateCache().put(key, data);
    }

    public static Object getStateNamedCache(Object key) {
        return getStateCache().get(key);
    }

    public static NamedCache getPreferredLanguageCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_PREFERRED_LANGUAGE_KEY);
    }

    public static synchronized void updatePreferredLanguage(Object key, Object data) {
        getPreferredLanguageCache().put(key, data);
    }

    public static Object getPreferredLanguage(Object key) {
        return getPreferredLanguageCache().get(key);
    }

    public static NamedCache getLocaleCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_LOCALE_KEY);
    }

    public static synchronized void updateLocale(Object key, Object data) {
        getLocaleCache().put(key, data);
    }

    public static Object getLocale(Object key) {
        return getLocaleCache().get(key);
    }

    /**
     * @return Banned Accounts from Cache
     */
    private static NamedCache getBannedAccountNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_BANNEDACCOUNT_CACHE);
    }

    /**
     * @param data
     */
    public static synchronized void updateBannedAccountCache(List<String> data) {
        getBannedAccountNamedCache().put("BannedAccount", data);
    }

    /**
     * @return List of Accounts
     */
    public static synchronized List<String> getBannedAccountCache() {
        return (List<String>)getBannedAccountNamedCache().get("BannedAccount");
    }

    /**
     * @param accountIds
     * @return
     */
    public static boolean containsBannedAccountCache(List<String> accountIds) {
        List<String> cacheValues = (List<String>)getBannedAccountNamedCache().get("BannedAccount");
        boolean returnValue = false;
        for (String accountId : accountIds) {
            returnValue = cacheValues.contains(accountId);
            if (returnValue) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param accountIds
     * @return
     */
    public static boolean containsAllBannedAccountsCache(List<String> accountIds) {
        List<String> cacheValues = (List<String>)getBannedAccountNamedCache().get("BannedAccount");

        return cacheValues.containsAll(accountIds);
    }

    /**
     * @param accountId
     * @return
     */
    public static boolean containsBannedAccountCache(String accountId) {
        List<String> cacheValues = (List<String>)getBannedAccountNamedCache().get("BannedAccount");

        return cacheValues.contains(accountId);
    }

    /**
     * @return Point Product Attributes from Cache
     */
    private static NamedCache getPointProducAttrNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_POINT_PRODUCT_ATTR_CACHE);
    }

    /**
     * @param data
     */
    public static synchronized void updatePointProductAttrCache(Map<String, HashMap<String, String>> data) {
        getPointProducAttrNamedCache().put("PointProductAttr", data);
    }

    /**
     * @return HashMap of Point Product Attributes
     */
    public static synchronized Map<String, HashMap<String, String>> getPointProductAttrCache() {
        return (Map<String, HashMap<String, String>>)getPointProducAttrNamedCache().get(SPRConstants.COHERENCE_POINT_PRODUCT_ATTR_KEY);
    }

    /**
     * @return HashMap of Point Product Attributes for given product row id
     */
    public static synchronized HashMap<String, String> getPointProductAttrForProductCache(String productRowId) {
        Map<String, HashMap<String, String>> cacheValues =
            (Map<String, HashMap<String, String>>)getPointProducAttrNamedCache().get(SPRConstants.COHERENCE_POINT_PRODUCT_ATTR_KEY);

        if (cacheValues == null) {
            return null;
        } else {
            return cacheValues.get(productRowId);
        }
    }

    /**
     * @return Restricted Countries from Cache
     */
    private static NamedCache getRestrictedCountriesNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_RESTRICTED_COUNTRIES_CACHE);
    }

    /**
     * @param data
     */
    public static synchronized void updateRestrictedCountriesCache(List<String> data) {
        getRestrictedCountriesNamedCache().put(SPRConstants.COHERENCE_RESTRICTED_COUNTRIES_KEY, data);
    }

    /**
     * @return HashMap of Restricted Countries
     */
    public static synchronized List<String> getRestrictedCountriesCache() {
        return (List<String>)getRestrictedCountriesNamedCache().get(SPRConstants.COHERENCE_RESTRICTED_COUNTRIES_KEY);
    }

    /**
     * @return Products from Cache
     */
    private static NamedCache getSPRProductsNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_SPR_PRODUCTS_CACHE);
    }

    /**
     * @param data
     */
    public static synchronized void updateSPRProductsCache(HashMap<String, Object> data) {
        getSPRProductsNamedCache().put(SPRConstants.COHERENCE_SPR_PRODUCTS_KEY, data);
    }

    /**
     * @return HashMap of Products
     */
    public static synchronized HashMap<String, Object> getSPRProductsCache() {
        return (HashMap<String, Object>)getSPRProductsNamedCache().get(SPRConstants.COHERENCE_SPR_PRODUCTS_KEY);
    }


    public static NamedCache getLanguagesCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_SPR_LANGUAGES_CACHE);
    }

    public static synchronized void updateLanguagesCache(Object key, Object data) {
        getLanguagesCache().put(key, data);
    }

    public static Object getLanguagesNamedCache(Object key) {
        return getLanguagesCache().get(key);
    }

    private static NamedCache getSearchTermNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_SPR_SEARCHTERM_AS_CACHE);
    }

    public static synchronized void updateSearchTermCache(Object data) {
        getSearchTermNamedCache().put(SPRConstants.COHERENCE_SPR_SEARCHTERM_AS_CACHE_KEY, data);
    }

    public static Object getSearchTermCache() {
        return getSearchTermNamedCache().get(SPRConstants.COHERENCE_SPR_SEARCHTERM_AS_CACHE_KEY);
    }

    private static NamedCache getKCSearchNamedCache() {
        return CacheFactory.getCache(SPRConstants.COHERENCE_SPR_KC_SEARCH_CACHE);
    }

    public static synchronized void updateKCSearchCache(Object key,Object data) {
        getKCSearchNamedCache().put(key, data);
    }

    public static Object getKCSearchCache(Object key) {
        return getKCSearchNamedCache().get(key);
    }
    public static synchronized void clearKCSearchCache() {
        getKCSearchNamedCache().clear();
    }

}
