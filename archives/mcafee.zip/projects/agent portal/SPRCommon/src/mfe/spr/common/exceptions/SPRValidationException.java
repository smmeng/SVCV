package mfe.spr.common.exceptions;

public class SPRValidationException extends RuntimeException {

    @SuppressWarnings("compatibility:6437981128589959004")
    private static final long serialVersionUID = 1578935818462435763L;
    private String errorCode;

    public SPRValidationException(String pErrorCode, String pMessage, Throwable pThrowable) {
        super(pMessage, pThrowable);
        errorCode = pErrorCode;
    }

    public SPRValidationException(String pErrorCode, String pMessage) {
        this(pErrorCode, pMessage, null);
    }

    public String getErrorCode() {
        return errorCode;
    }
}
