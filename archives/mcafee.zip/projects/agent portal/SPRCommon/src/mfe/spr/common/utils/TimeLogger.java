package mfe.spr.common.utils;

import java.util.logging.Level;

import oracle.adf.share.logging.ADFLogger;


public class TimeLogger {
    private final static String className = TimeLogger.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(TimeLogger.class);
    private static ADFLogger classLogger = null;
    private long start = -1;

    //    public TimeLogger() {
    //        super();
    //    }
    //
    //    public TimeLogger(boolean startImmediately) {
    //        super();
    //        if (startImmediately) {
    //            start();
    //        }
    //    }

    public TimeLogger(ADFLogger classLogger) {
        super();
        this.classLogger = classLogger;
    }

    public TimeLogger(ADFLogger classLogger, boolean startImmediately) {
        super();
        this.classLogger = classLogger;
        if (startImmediately) {
            start();
        }
    }

    public static void main(String[] args) {
        TimeLogger timeLogger = new TimeLogger(logger, true);
        timeLogger.stop("dave", "method", "testing");
        timeLogger.start();
        timeLogger.stop("dave", "action");
        timeLogger.start();
        timeLogger.stop();
        timeLogger.start();
        timeLogger.stop("my message");
    }

    public void start() {
        this.start = System.currentTimeMillis();
    }

    public void stop(Object obj, String methodName, String msg) {
        stop(obj.getClass().getName(), methodName, msg);
    }

    public void stop(Object obj, String methodName) {
        stop(obj.getClass().getName(), methodName, null);
    }

    public void stop(String className, String methodName) {
        stop(className, methodName, null);
    }

    public void stop(String msg) {
        stop(null, null, msg);
    }

    public void stop() {
        stop(null, null, null);
    }

    public void stop(String pClassName, String pMethodName, String msg) {
        ADFLogger mainLogger = classLogger != null ? classLogger : logger;
        boolean mainLoggerFinest = mainLogger.isFinest();

        String methodName = "stop(String, String, String)";
        if (start == -1) {
            logger.warning("Called stop without calling start.");
        } else if (mainLoggerFinest || logger.isFinest()) {
            String logMsg = "Execution took " + (System.currentTimeMillis() - start) + " milliseconds.";
            if (pClassName != null || pMethodName != null) {
                logMsg += " class: " + pClassName + ", methodName: " + pMethodName;
            }
            if (msg != null) {
                logMsg += ", msg: " + msg;
            }
            if (mainLoggerFinest) {
                mainLogger.logp(Level.FINEST, pClassName, methodName, logMsg);
            } else {
                logger.logp(Level.FINEST, pClassName, methodName, logMsg);
            }
        }
        start = -1;
    }

}
