package mfe.spr.common.utils;
//
//import java.sql.Timestamp;
//
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//
//import java.util.Calendar;
//import java.util.Date;
//import java.util.GregorianCalendar;
//import java.util.TimeZone;
//
//import oracle.adf.share.logging.ADFLogger;
//
//import oracle.jbo.JboException;
//
///**
// * Defines a common Date and Time utility object.
// *
// */
public class DateTimeUtil {
    //
    //    private static ADFLogger _logger = ADFLogger.createADFLogger(DateTimeUtil.class);
    //
    //    private static DateTimeUtil sSingleton = new DateTimeUtil();
    //
    //    //non-leap
    //    private static int[] DAYS_OF_MONTH_TO_QUARTER = new int[] { 0, 31, 59, 90, 30, 61, 91, 31, 62, 92, 31, 61 };
    //    //leap
    //    private static int[] LEAP_DAYS_OF_MONTH_TO_QUARTER = new int[] { 0, 31, 60, 91, 30, 61, 91, 31, 62, 92, 31, 61 };
    //
    //    // Formats for Programmatic Use
    //    // Formats for User Interface should be retrieved from User Profile.
    //    private static String XX_DATE_TIME_FORMAT = "yyyyMMdd HHmmss";
    //    private static String XX_DATE_FORMAT = "yyyyMMdd";
    //    private static String XX_TIME_FORMAT = "HHmmss";
    //    private static String XX_DATE_TIME_MILLIS_FORMAT = "yyyyMMdd HHmmssSSS";
    //
    //    private static String END_OF_DAY_TIME = " 235959";
    //    private static String START_OF_DAY_TIME = " 000000";
    //
    //    // Thread Local for utility objects
    //    private ThreadLocal<GregorianCalendar> mCalendarTL = new ThreadLocal<GregorianCalendar>();
    //    private ThreadLocal<SimpleDateFormat> mFormatterTL = new ThreadLocal<SimpleDateFormat>();
    //
    //    /**
    //     * private constructor for single object per application
    //     */

    private DateTimeUtil() {
        super();
    }
    //
    //    /**
    //     *  Returns DateTimeUtil singleton instance
    //     * @return
    //     */
    //    public static DateTimeUtil singleton() {
    //        return sSingleton;
    //    }
    //
    //    /**
    //     * Receive Date as parameter and check for day is weekday
    //     * @param pDate
    //     * @return boolean
    //     */
    //    public boolean isWeekday(Date pDate, TimeZone pTimeZone) {
    //        int day = getDayOfWeek(pDate, pTimeZone);
    //        if ((day != Calendar.SUNDAY) && (day != Calendar.SATURDAY)) {
    //            return true;
    //        }
    //        return false;
    //    }
    //
    //    /**
    //     * Receive Date as parameter and check for day is weekend
    //     * @param pDate
    //     * @return boolean
    //     */
    //    public boolean isWeekend(Date pDate, TimeZone pTimeZone) {
    //        int day = getDayOfWeek(pDate, pTimeZone);
    //        if ((day == Calendar.SUNDAY) || (day == Calendar.SATURDAY)) {
    //            return true;
    //        }
    //        return false;
    //    }
    //
    //    /**
    //     * Return the String representation of given java.util.Date as per format supplied.
    //     *
    //     * @param pDate
    //     * @param pFormat
    //     * @param pTimeZone
    //     * @return String
    //     */
    //    public String formatDateTime(Date pDate, String pFormat, TimeZone pTimeZone) {
    //        String formattedString = null;
    //        SimpleDateFormat formatterForThread = getFormatterForCurrentThread();
    //
    //        formatterForThread.applyPattern(pFormat);
    //        formatterForThread.setLenient(false);
    //        formatterForThread.setTimeZone(pTimeZone);
    //
    //        formattedString = formatterForThread.format(pDate);
    //        return formattedString;
    //    }
    //
    //    /**
    //     * Return the java.util.Date for given String date and format and timezone
    //     *
    //     * @param pDate
    //     * @param pFormat
    //     * @param pTimeZone
    //     * @return Date
    //     */
    //    public Date parse(String pDate, String pFormat, TimeZone pTimeZone) {
    //        Date parsedDate = null;
    //        SimpleDateFormat formatterForThread = getFormatterForCurrentThread();
    //        formatterForThread.setLenient(false);
    //        formatterForThread.setTimeZone(pTimeZone);
    //        formatterForThread.applyPattern(pFormat);
    //
    //        try {
    //            parsedDate = formatterForThread.parse(pDate);
    //        } catch (ParseException e) {
    //            throw new JboException(e);
    //        }
    //        return parsedDate;
    //    }
    //
    //    /**
    //     * Return the java.util.Date for given String date and format and timezone
    //     *
    //     * @param pDate
    //     * @param pFormat
    //     * @param pTimeZone
    //     * @return
    //     */
    //    public Date parseToJavaDate(String pDate, String pFormat, TimeZone pTimeZone) {
    //        return parse(pDate, pFormat, pTimeZone);
    //    }
    //
    //    /**
    //     * Return the oracle.jbo.domain.Date for given String date and format and timezone
    //     *
    //     * @param pDate
    //     * @param pFormat
    //     * @param pTimeZone
    //     * @return
    //     */
    //    public oracle.jbo.domain.Date parseToJboDate(String pDate, String pFormat, TimeZone pTimeZone) {
    //        return toJboDate(parse(pDate, pFormat, pTimeZone));
    //    }
    //
    //    /**
    //     * Return SimpleDateFormat from ThreadLocal
    //     *
    //     * @return
    //     */
    //    private SimpleDateFormat getFormatterForCurrentThread() {
    //        SimpleDateFormat formatterForThread = null;
    //
    //        formatterForThread = mFormatterTL.get();
    //
    //        if (formatterForThread == null) {
    //            formatterForThread = new SimpleDateFormat(XX_DATE_TIME_FORMAT);
    //            formatterForThread.setLenient(false);
    //            mFormatterTL.set(formatterForThread);
    //        }
    //        return formatterForThread;
    //    }
    //
    //    /**
    //     * Returns GregorianCalendar form ThreadLocal
    //     * @return
    //     */
    //    private GregorianCalendar getCalendarForCurrentThread() {
    //        GregorianCalendar calForThread = null;
    //
    //        calForThread = mCalendarTL.get();
    //
    //        if (calForThread == null) {
    //            calForThread = new GregorianCalendar();
    //            calForThread.setLenient(false);
    //            mCalendarTL.set(calForThread);
    //        }
    //        return calForThread;
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pDays
    //     * @param pTimeZone
    //     */
    //    public void addDays(Date pDate, int pDays, TimeZone pTimeZone) {
    //        addInternal(pDate, Calendar.DAY_OF_MONTH, pDays, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pHours
    //     * @param pTimeZone
    //     */
    //    public void addHours(Date pDate, int pHours, TimeZone pTimeZone) {
    //        addInternal(pDate, Calendar.HOUR, pHours, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pMinuts
    //     * @param pTimeZone
    //     */
    //    public void addMinutes(Date pDate, int pMinuts, TimeZone pTimeZone) {
    //        addInternal(pDate, Calendar.MINUTE, pMinuts, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pMonths
    //     * @param pTimeZone
    //     */
    //    public void addMonths(Date pDate, int pMonths, TimeZone pTimeZone) {
    //        addInternal(pDate, Calendar.MONTH, pMonths, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pSeconds
    //     * @param pTimeZone
    //     */
    //    public void addSeconds(Date pDate, int pSeconds, TimeZone pTimeZone) {
    //        addInternal(pDate, Calendar.SECOND, pSeconds, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pMilliSeconds
    //     * @param pTimeZone
    //     */
    //    public void addMilliSeconds(Date pDate, int pMilliSeconds, TimeZone pTimeZone) {
    //        addInternal(pDate, Calendar.MILLISECOND, pMilliSeconds, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pWeeks
    //     * @param pTimeZone
    //     */
    //    public void addWeeks(Date pDate, int pWeeks, TimeZone pTimeZone) {
    //        addInternal(pDate, Calendar.WEEK_OF_YEAR, pWeeks, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pYears
    //     * @param pTimeZone
    //     */
    //    public void addYears(Date pDate, int pYears, TimeZone pTimeZone) {
    //        addInternal(pDate, Calendar.YEAR, pYears, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return int
    //     */
    //    public int getYear(Date pDate, TimeZone pTimeZone) {
    //        return getInternal(pDate, Calendar.YEAR, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return int
    //     */
    //    public int getWeekOfMonth(Date pDate, TimeZone pTimeZone) {
    //        return getInternal(pDate, Calendar.WEEK_OF_MONTH, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return int
    //     */
    //    public int getWeekOfYear(Date pDate, TimeZone pTimeZone) {
    //        return getInternal(pDate, Calendar.WEEK_OF_YEAR, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return
    //     */
    //    public int getMonthOfYear(Date pDate, TimeZone pTimeZone) {
    //        return getInternal(pDate, Calendar.MONTH, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return
    //     */
    //    public int getDayOfMonth(Date pDate, TimeZone pTimeZone) {
    //        return getInternal(pDate, Calendar.DAY_OF_MONTH, pTimeZone);
    //    }
    //
    //    /**
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return
    //     */
    //    public int getDayOfYear(Date pDate, TimeZone pTimeZone) {
    //        return getInternal(pDate, Calendar.DAY_OF_YEAR, pTimeZone);
    //    }
    //
    //    /**
    //     * Return Day number in week of given date
    //     * Sunday is 1st and Saturday is 7th
    //     *
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return
    //     */
    //    public int getDayOfWeek(Date pDate, TimeZone pTimeZone) {
    //        return getInternal(pDate, Calendar.DAY_OF_WEEK, pTimeZone);
    //    }
    //
    //    /**
    //     * Add pAmount for given date as per type in specific timezone.
    //     * @param pDate
    //     * @param pType
    //     * @param pAmount
    //     * @param pTimeZone
    //     */
    //    private void addInternal(Date pDate, int pType, int pAmount, TimeZone pTimeZone) {
    //        GregorianCalendar calForThread = getCalendarForCurrentThread();
    //        calForThread.setLenient(false);
    //        calForThread.setTimeZone(pTimeZone);
    //        calForThread.setTime(pDate);
    //        calForThread.add(pType, pAmount);
    //        pDate.setTime(calForThread.getTimeInMillis());
    //    }
    //
    //    /**
    //     *
    //     * @param pDate
    //     * @param pType
    //     * @param pTimeZone
    //     * @return
    //     */
    //    private int getInternal(Date pDate, int pType, TimeZone pTimeZone) {
    //        GregorianCalendar calForThread = getCalendarForCurrentThread();
    //        calForThread.setLenient(false);
    //        calForThread.setTimeZone(pTimeZone);
    //        calForThread.setTime(pDate);
    //        return calForThread.get(pType);
    //    }
    //
    //    /**
    //     *
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return
    //     */
    //    public Date getEndOfDay(Date pDate, TimeZone pTimeZone) {
    //        String mEndOfDay = formatDateTime(pDate, XX_DATE_FORMAT, pTimeZone) + END_OF_DAY_TIME;
    //        return parse(mEndOfDay, XX_DATE_TIME_FORMAT, pTimeZone);
    //    }
    //
    //    /**
    //     *
    //     * @param pDate
    //     * @param pTimeZone
    //     * @return
    //     */
    //    public Date getStartOfDay(Date pDate, TimeZone pTimeZone) {
    //        String mStartOfDay = formatDateTime(pDate, XX_DATE_FORMAT, pTimeZone) + START_OF_DAY_TIME;
    //        return parse(mStartOfDay, XX_DATE_TIME_FORMAT, pTimeZone);
    //    }
    //
    //    /**
    //     * Convert to Jbo Date. Does not preserve millisecond value.
    //     *
    //     * @param pJavaDate
    //     * @return
    //     */
    //    public oracle.jbo.domain.Date toJboDate(java.util.Date pJavaDate) {
    //        return new oracle.jbo.domain.Date(new Timestamp(pJavaDate.getTime()));
    //    }
    //
    //    /**
    //     * Convert to Java Date. Does not preserve millisecond value.
    //     *
    //     * @param pJboDate
    //     * @return
    //     */
    //    public Date toJavaDate(oracle.jbo.domain.Date pJboDate) {
    //        return new Date(pJboDate.timestampValue().getTime());
    //    }
    //
    //    /**
    //     *
    //     * @param date
    //     * @return
    //     */
    //    public int getDayOfQuarter(Date date, TimeZone pTimeZone) {
    //        GregorianCalendar gCal = getCalendarForCurrentThread();
    //        gCal.setTime(date);
    //        gCal.setTimeZone(pTimeZone);
    //
    //        int dayOfMonth = gCal.get(Calendar.DAY_OF_MONTH);
    //        int month = gCal.get(Calendar.MONTH);
    //        int dayOfYear = 0;
    //
    //        if (gCal.isLeapYear(gCal.get(java.util.Calendar.YEAR))) {
    //            return LEAP_DAYS_OF_MONTH_TO_QUARTER[month] + dayOfMonth;
    //        } else {
    //            return dayOfYear - DAYS_OF_MONTH_TO_QUARTER[month] + dayOfMonth;
    //        }
    //    }
    //
    //    /**
    //     * Return current java.util.Date.
    //     *
    //     * @return
    //     */
    //    public Date getCurrentUtilDateWithTime() {
    //        return new Date(System.currentTimeMillis());
    //    }
    //
    //    /**
    //     * Get the current jbo date without time information.
    //     *
    //     * @return
    //     */
    //    public oracle.jbo.domain.Date getCurrentJboDate() {
    //        return new oracle.jbo.domain.Date(new java.sql.Date(System.currentTimeMillis()));
    //    }
    //
    //    /**
    //     * Get the current jbo date including time.
    //     *
    //     * @return
    //     */
    //    public oracle.jbo.domain.Date getCurrentJboDateWithTime() {
    //        return new oracle.jbo.domain.Date(new Timestamp(System.currentTimeMillis()));
    //    }
    //
    //    /**
    //     * Returns true if supplied date is in future.
    //     *
    //     * @param pDate
    //     * @return
    //     */
    //    public boolean isFutureDate(Date pDate) {
    //        return new Date().before(pDate);
    //    }
    //
    //    /**
    //     * Return true if the first date is before the second date.
    //     *
    //     * @param pFromDate
    //     * @param pToDate
    //     * @return
    //     */
    //    public boolean before(Date pFromDate, Date pToDate) {
    //        return pFromDate.before(pToDate);
    //    }
    //
    //    /**
    //     * Return true if both the dates are in a rage, i.e the first date
    //     * is before the second date.
    //     *
    //     * @param pFromDate
    //     * @param pToDate
    //     * @return
    //     */
    //    public boolean isRangeOK(Date pFromDate, Date pToDate) {
    //        return pFromDate.before(pToDate);
    //    }
    //
    //    /**
    //     * Return true if supplied date is in past.
    //     *
    //     * @param pDate
    //     * @return
    //     */
    //    public boolean isPastDate(Date pDate) {
    //        return pDate.before(new Date());
    //    }
    //
    //    /**
    //     * Return true if the first date is after the second date.
    //     *
    //     * @param pFromDate
    //     * @param pToDate
    //     * @return
    //     */
    //    public boolean after(Date pFromDate, Date pToDate) {
    //        return pFromDate.after(pToDate);
    //    }
    //
    //    /**
    //     * Return true if the first date is after the second date.
    //     *
    //     * @param pFromDate
    //     * @param pToDate
    //     * @return
    //     */
    //    public boolean after(oracle.jbo.domain.Date pFromDate, oracle.jbo.domain.Date pToDate) {
    //        return (toJavaDate(pFromDate)).after(toJavaDate(pToDate));
    //    }
    //
    //    /**
    //     * Return true if the first date is before the second date.
    //     *
    //     * @param pFromDate
    //     * @param pToDate
    //     * @return
    //     */
    //    public boolean before(oracle.jbo.domain.Date pFromDate, oracle.jbo.domain.Date pToDate) {
    //        return before(toJavaDate(pFromDate), toJavaDate(pToDate));
    //    }
    //
    //    /**
    //     * Return true if both the dates are in a rage, i.e the first date
    //     * is before the second date.
    //     *
    //     * @param pFromDate
    //     * @param pToDate
    //     * @return
    //     */
    //    public boolean isRangeOK(oracle.jbo.domain.Date pFromDate, oracle.jbo.domain.Date pToDate) {
    //        return isRangeOK(toJavaDate(pFromDate), toJavaDate(pToDate));
    //    }
    //
    //    /**
    //     * Returns true if supplied date is in future.
    //     *
    //     * @param pDate
    //     * @return
    //     */
    //    public boolean isFutureDate(oracle.jbo.domain.Date pDate) {
    //        return new Date().before(toJavaDate(pDate));
    //    }
    //
    //    /**
    //     * Return true if supplied date is in past.
    //     *
    //     * @param pDate
    //     * @return
    //     */
    //    public boolean isPastDate(oracle.jbo.domain.Date pDate) {
    //        return toJavaDate(pDate).before(new Date());
    //    }
    //
    //
    //    /**
    //     * Add work days. Not counting SAT and SUN.
    //     *
    //     * @param pDate
    //     * @param pDays
    //     * @param pTimeZone
    //     */
    //    public void addWorkDays(Date pDate, int pDays, TimeZone pTimeZone) {
    //        GregorianCalendar calForThread = getCalendarForCurrentThread();
    //        calForThread.setLenient(false);
    //        calForThread.setTimeZone(pTimeZone);
    //        calForThread.setTime(pDate);
    //
    //        // every 5 work days count for one week
    //        int weeks = pDays / 5;
    //        int extraDays = pDays % 5;
    //
    //        // real week has 7 days
    //        int daysForWeeks = 7 * weeks;
    //
    //        if (daysForWeeks != 0) {
    //            calForThread.add(Calendar.DAY_OF_MONTH, daysForWeeks);
    //        }
    //
    //        int increment = 1;
    //        if (extraDays < 0) {
    //            increment = -1;
    //            extraDays = extraDays * -1;
    //        }
    //
    //        while (extraDays > 0) {
    //            // add to day of month
    //            calForThread.add(Calendar.DAY_OF_MONTH, increment);
    //            // check day of week - is it weekend?
    //            int curDay = calForThread.get(Calendar.DAY_OF_WEEK);
    //            while (curDay == Calendar.SUNDAY || curDay == Calendar.SATURDAY) {
    //                calForThread.add(Calendar.DAY_OF_MONTH, increment);
    //                curDay = calForThread.get(Calendar.DAY_OF_WEEK);
    //            }
    //            extraDays = extraDays - 1;
    //        }
    //
    //        // if supplied date was weekend and there were no extra days
    //        int curDay = calForThread.get(Calendar.DAY_OF_WEEK);
    //        // check day of week - is it weekend?
    //        while (curDay == Calendar.SUNDAY || curDay == Calendar.SATURDAY) {
    //            calForThread.add(Calendar.DAY_OF_MONTH, increment);
    //            curDay = calForThread.get(Calendar.DAY_OF_WEEK);
    //        }
    //
    //        // finally set millis value on Date.
    //        pDate.setTime(calForThread.getTimeInMillis());
    //    }
    //
    //    private void setInternal(Date pDate, int pType, int pValue, TimeZone pTimeZone) {
    //        GregorianCalendar calForThread = getCalendarForCurrentThread();
    //        calForThread.setLenient(false);
    //        calForThread.setTimeZone(pTimeZone);
    //        calForThread.setTime(pDate);
    //        calForThread.set(pType, pValue);
    //        pDate.setTime(calForThread.getTimeInMillis());
    //    }
    //
    //    /**
    //     * Set Date to supplied value.
    //     * The first day of the month has value 1.
    //     *
    //     * @param pDate
    //     * @param pValue
    //     * @param pTimeZone
    //     */
    //    public void setDate(Date pDate, int pValue, TimeZone pTimeZone) {
    //        setInternal(pDate, Calendar.DATE, pValue, pTimeZone);
    //    }
    //
    //    /**
    //     * Set month to supplied value.
    //     * First month of year has value 0.
    //     *
    //     * @param pDate
    //     * @param pValue
    //     * @param pTimeZone
    //     */
    //    public void setMonth(Date pDate, int pValue, TimeZone pTimeZone) {
    //        setInternal(pDate, Calendar.MONTH, pValue, pTimeZone);
    //    }
    //
    //    /**
    //     * Set Year to supplied value.
    //     *
    //     * @param pDate
    //     * @param pValue
    //     * @param pTimeZone
    //     */
    //    public void setYear(Date pDate, int pValue, TimeZone pTimeZone) {
    //        setInternal(pDate, Calendar.YEAR, pValue, pTimeZone);
    //    }
    //
    //    /**
    //     * Set Hour of day to supplied value.
    //     * 24 Hour clock. 0 to 23.
    //     *
    //     * @param pDate
    //     * @param pValue
    //     * @param pTimeZone
    //     */
    //    public void setHourOfDay(Date pDate, int pValue, TimeZone pTimeZone) {
    //        setInternal(pDate, Calendar.HOUR_OF_DAY, pValue, pTimeZone);
    //    }
    //
    //    /**
    //     * Set minute to supplied value.
    //     *
    //     * @param pDate
    //     * @param pValue
    //     * @param pTimeZone
    //     */
    //    public void setMinute(Date pDate, int pValue, TimeZone pTimeZone) {
    //        setInternal(pDate, Calendar.MINUTE, pValue, pTimeZone);
    //    }
    //
    //    /**
    //     * Set second to supplied value.
    //     *
    //     * @param pDate
    //     * @param pValue
    //     * @param pTimeZone
    //     */
    //    public void setSecond(Date pDate, int pValue, TimeZone pTimeZone) {
    //        setInternal(pDate, Calendar.SECOND, pValue, pTimeZone);
    //    }
    //
}
