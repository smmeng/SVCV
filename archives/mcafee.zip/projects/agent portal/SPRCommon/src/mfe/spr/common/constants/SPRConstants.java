package mfe.spr.common.constants;

public abstract class SPRConstants {


    private final static String CLASS_NAME = SPRConstants.class.getName();

    public static String APPLICATION_NAME = "SPR";
    public static String APP_AGT = "AGT";
    public static String PROPERTIES_APP_NAME = "SPR_CUSTOM";

    public static String COHERENCE_CONTENTQUERY_KEY = "srp.cache.contentquery";
    public static String COHERENCE_UACONTENT_KEY = "srp.cache.uacontent";
    public static String COHERENCE_RACONTENT_KEY = "srp.cache.racontent";
    public static String COHERENCE_PROPERTY_KEY = "spr.app.property";
    public static String COHERENCE_LOV_CACHE = "spr.cache.lov";
    public static String COHERENCE_PPA_KEY = "spr.cache.ppa";
    public static final String COHERENCE_BANNEDACCOUNT_CACHE = "spr.cache.bannedAccount";
    public static final String COHERENCE_GRANTNUMBER_CACHE = "spr.cache.grantnumber";
    public static final String COHERENCE_COUNTRY_REGION_KEY = "spr.cache.countryregion";
    public static final String COHERENCE_COUNTRY_KEY = "spr.cache.country";
    public static final String COHERENCE_COUNTRY_STATE_KEY = "spr.cache.countryState";
    public static final String COHERENCE_PREFERRED_LANGUAGE_KEY = "spr.cache.preferredLanguage";
    public static final String COHERENCE_LOCALE_KEY = "spr.cache.locale";
    public static final String COHERENCE_POINT_PRODUCT_ATTR_CACHE = "spr.cache.pointProductAttr";
    public static final String COHERENCE_RESTRICTED_COUNTRIES_CACHE = "spr.cache.restrictedCountries";
    public static final String COHERENCE_POINT_PRODUCT_ATTR_KEY = "PointProductAttr";
    public static final String COHERENCE_RESTRICTED_COUNTRIES_KEY = "RestrictedCountries";
    public static final String COHERENCE_SPR_PRODUCTS_CACHE = "spr.cache.sprProducts";
    public static final String COHERENCE_SPR_LANGUAGES_CACHE = "spr.cache.sprLanguages";
    public static final String COHERENCE_SPR_SEARCHTERM_AS_CACHE = "spr.cache.sprSearchTermAS";
    public static final String COHERENCE_SPR_KC_SEARCH_CACHE = "spr.cache.sprSearchResult";
    public static final String COHERENCE_SPR_SEARCHTERM_AS_CACHE_KEY = "SearchTermAS";
    public static final String COHERENCE_SPR_PRODUCTS_KEY = "SPRProducts";
    public static final String SUPPORTED_LANGUAGES = "SUPPORTED_LANGUAGES";

    public static final String LOCALE_SEPARATOR = "-";

    public static final String ALL_LOV_TYPES_KEY = "ALL_LOV_TYPES";
    public static final String ESERVICE_LITE_WSDL_URL_KEY = "ESERVICE_LITE_WSDL_URL";
    public static final String SR_STATUS_MAP_KEY = "SR_STATUS_MAP_KEY";
    public static final String AVERT_WSDL_URL_KEY = "AVERT_WSDL_URL";
    public static final String SEIBEL_EXTRACT_WSDL_URL_KEY = "SIEBEL_EXTRACT_WSDL_URL";
    public static final String SECURITY_MANAGER_WSDL_URL_KEY = "SECURITY_MANAGER_WSDL_URL";

    public static final String MFE_LABS_ISSUE_TYPE_CACHE_KEY = "MFE_LABS_ISSUE_TYPE_CACHE_KEY";
    public static final String PREFERRED_LANGUAGE_CACHE_KEY = "PREFERRED_LANGUAGE_CACHE_KEY";
    public static final String TIMEZONE_CACHE_KEY = "TIMEZONE_CACHE_KEY";

    public static final String SEARCH_SR_STATUS_LOV = "SEARCH_SR_STATUS_LOV";
    public static final String SUBMIT_SAMPLE_FILEUPLOAD_TEMP_PATH = "SUBMIT_SAMPLE_FILEUPLOAD_TEMP_PATH";
    public static final String SUBMIT_SAMPLE_FILEUPLOAD_PATH = "SUBMIT_SAMPLE_FILEUPLOAD_PATH";
    public static final String DIAGNOSTIC_FILEUPLOAD_PATH = "DIAGNOSTIC_FILEUPLOAD_PATH";
    public static final String SEARCH_SR_FETCH_COUNT = "SEARCH_SR_FETCH_COUNT";
    public static final String ENVIRONMENT_DOCS_FILEUPLOAD_PATH = "DIAGNOSTIC_FILEUPLOAD_PATH";
    public static final String SIEBEL_DATE_TIME_FORMAT = "MM/dd/yyyy hh:mm:ss a";
    public static final String SIEBEL_DATE_TIME_FORMAT2 = "MM/dd/yyyy HH:mm:ss";
    public static final String SIEBEL_SERVICE_POLL_INTERVAL_MINUTES = "SIEBEL_SERVICE_POLL_INTERVAL_MINUTES";
    public final static String SIEBEL_SESSION_TIMEOUT_MSG =
        "System.Web.Services.Protocols.SoapException: Session does not exist.";
    public final static String DIAGNOSTIC_FILEUPLOAD_UNC_PATH = "DIAGNOSTIC_FILEUPLOAD_UNC_PATH";
    public final static String DIAGNOSTIC_FILEUPLOAD_UNC_WINDOWS_PATH = "DIAGNOSTIC_FILEUPLOAD_UNC_WINDOWS_PATH";
    public final static String JUPLOAD_JAR_PATH = "JUPLOAD_JAR_URL";
    public final static String JUPLOAD_MAX_CHUNK_SIZE = "JUPLOAD_MAX_CHUNK_SIZE";
    public final static String JUPLOAD_MAX_FILE_SIZE = "JUPLOAD_MAX_FILE_SIZE";
    public final static String JUPLOAD_BUFFER_SIZE = "JUPLOAD_BUFFER_SIZE";
    public final static String JUPLOAD_DEBUG_LEVEL = "JUPLOAD_DEBUG_LEVEL";
    public final static String JUPLOAD_ALLOW_HTTP_PERSISTENT = "JUPLOAD_ALLOW_HTTP_PERSISTENT";
    public final static String JUPLOAD_HIDE_BUFFER_SIZE_INPUT_BOX = "JUPLOAD_HIDE_BUFFER_SIZE_INPUT_BOX";
    public final static String JAVA_DOWNLOAD_PATH = "JAVA_DOWNLOAD_PATH";
    public final static String JAVA_DOWNLOAD_PAGE = "JAVA_DOWNLOAD_PAGE";
    public final static String JAVA_DOWNLOAD_PATTERN = "JAVA_DOWNLOAD_PATTERN";
    public final static String JUPLOAD_ENABLE_DEBUG = "JUPLOAD_ENABLE_DEBUG";
    public final static String JUPLOAD_ENABLE_SERVER_LOG = "JUPLOAD_ENABLE_SERVER_LOG";
    public final static String FILETYPE_LOV_DATA = "FILETYPE_LOV_DATA";
    public final static String WINDOWS_SERVER_PATH_DIAGNOSTIC_UPLOAD = "WINDOWS_SERVER_PATH_DIAGNOSTIC_UPLOAD";
    public final static String WINDOWS_SERVER_PATH_SAMPLE_UPLOAD = "WINDOWS_SERVER_PATH_SAMPLE_UPLOAD";
    public final static String UPDATE_SIEBEL_ON_MER_FLAG_CHAGE = "UPDATE_SIEBEL_ON_MER_FLAG_CHAGE";

    // Start: File extension validation
    public final static String DIAGNOSTIC_FILE_EXTNS = "DIAGNOSTIC_FILE_EXTNS";
    public final static String DIAGNOSTIC_FILE_HD_EXTNS = "DIAGNOSTIC_FILE_HD_EXTNS";
    public final static String DIAGNOSTIC_FILE_MER_EXTNS = "DIAGNOSTIC_FILE_MER_EXTNS";
    public final static String DIAGNOSTIC_FILE_OTHERS_EXTNS = "DIAGNOSTIC_FILE_OTHERS_EXTNS";
    public final static String DIAGNOSTIC_FILE_SIZE = "BROWSER_DIAGNOSTIC_FILEUPLOAD_SIZE";
    // Start: File extension validation

    public final static String DIAGNOSTIC_FILEDOWNLOAD_PATH = "DIAGNOSTIC_FILEDOWNLOAD_PATH";
    public final static String WINDOWS_SERVER_PATH_DIAGNOSTIC_DOWNLOAD = "WINDOWS_SERVER_PATH_DIAGNOSTIC_DOWNLOAD";
    public final static String UCM_URL = "UCM_URL";

    public final static String ANNOYMOUS_USER_STRING = "SIEBEL_ANONYMOUS_USER";
    public final static String ANNOYMOUS_PSWD_STRING = "SIEBEL_ANONYMOUS_PASSWORD";
    public final static String PREFERRED_LANGUAGE_SEARCH_SPEC = "PREFERRED_LANGUAGE_SEARCH_SPEC";

    public final static String UCM_TOOLS_CONTENT_QUERY = "UCM_TOOLS_CONTENT_QUERY";

    public final static String SOCIAL_FEATURES_FACEBOOK = "SOCIAL_FEATURES_FACEBOOK";
    public final static String SOCIAL_FEATURES_GOOGLEPLUS = "SOCIAL_FEATURES_GOOGLEPLUS";
    public final static String SOCIAL_FEATURES_LINKEDIN = "SOCIAL_FEATURES_LINKEDIN";
    public final static String SOCIAL_FEATURES_TWITTER = "SOCIAL_FEATURES_TWITTER";
    public final static String SOCIAL_FEATURES_YOUTUBE = "SOCIAL_FEATURES_YOUTUBE";

    public final static String CREATESR_TECHNICAL_SUPPORT_LINK = "CREATESR_TECHNICAL_SUPPORT_LINK";
    public final static String URL_CONTACT_US = "URL_CONTACT_US";
    public final static String JAPAN_URL_CONTACT_US = "JAPAN_URL_CONTACT_US";
    public final static String MCAFEE_HOME_URL = "MCAFEE_HOME_URL";

    public final static String CREATESR_STEP2_MVT_URL = "CREATESR_STEP2_MVT_URL";
    public final static String TOOLS_MVT_URL = "TOOLS_MVT_URL";

    public final static String ENVIRONMENT_DOCS_FILE_EXTNS = "ENVIRONMENT_DOCS_FILE_EXTNS";

    public final static String SR_PERMISSION_VAR = "SR Management";
    public final static String CREATE_SR_PERMISSION_VAR = "Create SR";
    public final static String VIEW_COMPANY_SR_PERMISSION_VAR = "View Company SR";
    public final static String VIEW_TEAM_SR_PERMISSION_VAR = "View Team SR";
    public final static String VIEW_ENTITLEMENT_PERMISSION_VAR = "View Entitlement";
    public final static String DOWNLOAD_PATCH_PERMISSION_VAR = "Download Patch";

    public final static String LOCALE_URL_PARAMETER = "&lang=";
    public final static String LOCALE_PARAMETER = "lang";
    public final static String CREATESR_HOW_TO_CONTACT_DEFAULT_CHOICE = "Post Service Request Online";
    public final static String MVT_TOOLS_VALIDATION_WSDL_URL_KEY = "MVT_TOOLS_VALIDATION_WSDL_URL";
    public final static String MVT_TOOLS_REPORTS_URL_KEY = "MVT_TOOLS_REPORTS_URL";
    public final static String CUSTOM_MER_WEBSERVICE_WSDL_URL = "EMAIL_CUSTOM_MER_WSDL_URL";
    public static String SERVER_NAME = null;
    public final static String httpOnly = ";HttpOnly; secure";

    public final static String DOWNSTREAM_TIMEZONE_STR = "DWNSTRM_JOB_TZ";
    public final static String UPSTREAM_TIMEZONE_STR = "PRDT_CTLG_TZ";
    public final static String MST_TIMEZONE_STR = "America/Denver";
    public final static String SPR_ERROR_REPORT_FORM = "SPR_ERROR_REPORT_FORM";

    public final static String SAMPLE_SR_SEVERITY_DEFAULT = "SAMPLE_SR_SEVERITY_DEFAULT";

    public final static String SR_SRC_MALWARE = "McAfee Labs";
    public final static String OWNER_GROUP_ENTERPRISE = "Enterprise";
    public final static String OWNER_GROUP_TIER_1 = "Tier 1";
    public final static String SPR_SUI_CONSUMER_PRODUCT_REST_URL="SPR_SUI_CONSUMER_PRODUCT_REST_URL";
    public final static String SPR_SUI_CONSUMER_PRODUCT_ENABLE="SPR_SUI_CONSUMER_PRODUCT_ENABLE";
    public final static String SPR_SUI_CHAT_AGENT_AVILABLE_REST_URL="SPR_SUI_CHAT_AGENT_AVILABLE_REST_URL";

    // Variable to check if application running in contribution
    public static boolean isRunningInContribution = false;

    // Variable to check if application running in Agent contribution
    public static boolean isRunningInAgentContrib = false;


    public SPRConstants() {
        super();
    }

    static {
        String serverName = System.getProperty("weblogic.Name");
        SERVER_NAME = serverName;
        System.out.println("WEBLOGIC.NAME............:" + serverName);
        if (serverName.equalsIgnoreCase("Support_Contribution") || serverName.equalsIgnoreCase("SPR2_Contrib")) {
            isRunningInContribution = true;
            COHERENCE_CONTENTQUERY_KEY = "srp.cache.contrib.contentquery";
            COHERENCE_UACONTENT_KEY = "srp.cache.contrib.uacontent";
            COHERENCE_RACONTENT_KEY = "srp.cache.contrib.racontent";
            COHERENCE_PROPERTY_KEY = "spr.app.contrib.property";
            PROPERTIES_APP_NAME = "SPR_CONTRIB";
            COHERENCE_PPA_KEY = "spr.cache.ppa";
        }
        /*
           * Setup for agent consump first
           */
        if (serverName.contains("Agent")) {
            PROPERTIES_APP_NAME = "AGT_CUSTOM";
            APPLICATION_NAME = APP_AGT;
        }
        /*
           * if its contrib then overwrite for contrib
           */
        if (serverName.equalsIgnoreCase("Agent_Contrib")) {
            isRunningInAgentContrib = true;
            PROPERTIES_APP_NAME = "AGT_CONTRIB";
            COHERENCE_CONTENTQUERY_KEY = "srp.cache.contrib.contentquery";
            COHERENCE_UACONTENT_KEY = "srp.cache.contrib.uacontent";
            COHERENCE_RACONTENT_KEY = "srp.cache.contrib.racontent";
            COHERENCE_PROPERTY_KEY = "spr.app.contrib.property";
            APPLICATION_NAME = APP_AGT;
        }
        System.out.println("APPLICATION_NAME............:" + APPLICATION_NAME);
        System.out.println("COHERENCE_CONTENTQUERY_KEY............:" + COHERENCE_CONTENTQUERY_KEY);
        System.out.println("COHERENCE_UACONTENT_KEY............:" + COHERENCE_UACONTENT_KEY);
        System.out.println("COHERENCE_RACONTENT_KEY............:" + COHERENCE_RACONTENT_KEY);
        System.out.println("COHERENCE_PROPERTY_KEY............:" + COHERENCE_PROPERTY_KEY);
        System.out.println("PROPERTIES_APP_NAME............:" + PROPERTIES_APP_NAME);
        System.out.println("COHERENCE_PPA_KEY............:" + COHERENCE_PPA_KEY);
    }
}
