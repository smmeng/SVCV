import os

workspaceDir = os.getenv("WORKSPACE")

adminServerUrl = "#adminServerUrl#"
credKeysDir = '/opt/apps/jenkins/wls-creds'
userConfigFilePath = str(credKeysDir) + "/#userConfigFilePath#"
userKeyFilePath = str(credKeysDir) + "/#userKeyFilePath#"
applicationName = '#applicationName#'
targetServerName = '#targetServerName#'
mdRepoName = '#mdRepoName#'
mdRepoJndi = '#mdRepoJndi#'
mdRepoPartition = '#mdRepoPartition#'
adminUserName='#adminUserName#'
adminPassword='#adminPassword#'
entityType='#entityType#'

deployAppName = str(applicationName)

logPrefix = 'EA-Log-spr:: '
earLocation = str(workspaceDir) + '/' + 'deploy/' + str(deployAppName) + '.ear'

print logPrefix, str(earLocation)

# Connect to WebLogic server using the secured key
try:
    #connect(username=str(adminUserName), password=str(adminPassword), url=str(adminServerUrl))
	connect(userConfigFile=str(userConfigFilePath), userKeyFile=str(userKeyFilePath), url=str(adminServerUrl))
except Exception:
    dumpStack()
    os._exit(1)

# Shutdown managed server,by doing the shutdown first, we can do the deployment, restart quickly.
try:
    print logPrefix, 'Shutting down the server ....'
    shutdown(str(targetServerName), str(entityType), 'true', 1000, block='true')
    print logPrefix, 'Server stopped ....'
except Exception:
    dumpStack()
	
# Undeploy the application
try:
    domainConfig()
    print logPrefix, 'Entering Undeploy/deleteAppPolicies ' + str(applicationName) + '....' 
    deployedAppVersions=cmo.getAppDeployments()
    for deployedApp in deployedAppVersions:
		deployedAppName=deployedApp.getName()
		if str(applicationName) + '#' in deployedAppName:
			print logPrefix, 'Application Name ' + str(deployedAppName) + ' ....' 
			deployedAppVersion=deployedApp.getVersionIdentifier()
			print logPrefix, 'Version ' + str(deployedAppVersion) + ' ....' 

			# Undeploy
			print logPrefix, 'Undeploying ' + str(applicationName) + '....' 
			undeploy(str(applicationName), targets=str(targetServerName))
			print logPrefix, str(applicationName) + ' successfully got undeployed....' 

			# Delete App Policies
			print logPrefix, 'deleting app policies ' + str(deployedAppName) + '....' 
			deleteAppPolicies(appStripe=str(deployedAppName))
			print logPrefix, str(deployedAppName) + ' with version ' + str(deployedAppVersion) + ' policies successfully got deleted....' 
    print logPrefix, 'Exiting Undeploy/deleteAppPolicies ' + str(applicationName) + '....' 
except Exception:
    dumpStack()
    print logPrefix, 'test ' + str(applicationName) + '. Possibly this application with the name ' + str(applicationName) + ' does not exist. Please verify...'

try:
    # Register the WebCenter's Metadata Repository
    print logPrefix, 'Registering WebCenter\'s Metadata Repository for ' + str(applicationName) + ' ' + str(deployAppName) + '.ear'
    print logPrefix, 'EarLocation: ' + str(earLocation) + '$'
    print logPrefix, 'MDS Details: repository=' + str(mdRepoName) + ', partition=' + str(mdRepoPartition) + ', jndi=' + str(mdRepoJndi)
    archive=getMDSArchiveConfig(fromLocation=str(earLocation))
    archive.setAppMetadataRepository(repository=str(mdRepoName), partition=str(mdRepoPartition), type='DB', jndi=str(mdRepoJndi))
    archive.save()
    print logPrefix, 'Successfully registered WebCenter\'s Metadata Repository for ' + str(deployAppName) + '.ear'

    # Deploy the application to the targets
    print logPrefix, 'Deploying ' + str(applicationName) + ' to ' + str(targetServerName)
    print logPrefix, 'EarLocation: ' + str(earLocation) + '$'
    deploy(str(applicationName), str(earLocation), targets=str(targetServerName), upload='true')
    print logPrefix, str(deployAppName) + '.ear successfully got deployed with the name ' + str(applicationName) + '....' 
except Exception:
    dumpStack()
    errMsg = str(applicationName) + ' deployment failed. Please check the logs...'
    print logPrefix, str(errMsg)
    disconnect()
    os._exit(1)

# Start managed server
try:
    print logPrefix, 'Starting server ....'
    start(str(targetServerName), str(entityType), block='true')
    print logPrefix, 'Server started....'

    # Disconnects from the WLS and exits from WLST
    disconnect()
    os._exit(0)
except Exception:
    dumpStack()
    disconnect()
    os._exit(1)
	