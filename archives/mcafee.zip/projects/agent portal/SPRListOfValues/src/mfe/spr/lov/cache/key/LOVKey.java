package mfe.spr.lov.cache.key;

import java.io.Serializable;

public class LOVKey implements Serializable {

    @SuppressWarnings("compatibility:-5246360495870454190")
    private static final long serialVersionUID = 154466158976234111L;
    private String mLOVType;

    public LOVKey(String pLOVType) {
        super();
        mLOVType = pLOVType;
    }

    public String getLOVType() {
        return mLOVType;
    }

    public void setLOVType(String mLOVType) {
        this.mLOVType = mLOVType;
    }
}
