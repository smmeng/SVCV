package mfe.spr.lov.cache.value;


import com.mcafee.platinumportalws.listofvalues.ListOfValues;

import java.io.Serializable;

public class ListOfValue implements Serializable {
    @SuppressWarnings("compatibility:-6118400809669248317")
    private static final long serialVersionUID = 154466158976234456L;
    private String mId;
    private String mLOVType;
    private String mName;
    private String mValue;

    public ListOfValue(ListOfValues pWSLOV) {
        super();
        mId = pWSLOV.getId();
        mLOVType = pWSLOV.getType();
        mName = pWSLOV.getName();
        mValue = pWSLOV.getValue();
    }

    public String getId() {
        return mId;
    }

    public String getLOVType() {
        return mLOVType;
    }

    public String getName() {
        return mName;
    }

    public String getValue() {
        return mValue;
    }

    public void setId(String mId) {
        this.mId = mId;
    }

    public void setLOVType(String mLOVType) {
        this.mLOVType = mLOVType;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public void setValue(String mValue) {
        this.mValue = mValue;
    }
}
