package mfe.ea.locale.lwos;

import java.io.Serializable;

/**
 * McAfee Locale Object.
 */
public class MFELocale implements Serializable {

    @SuppressWarnings("compatibility:135746485943071413")
    private static final long serialVersionUID = -3196564718069439809L;

    private String localIdentifier;
    private String mfeLocale;
    private String localeCode;
    private String countryCode;
    private String displayLabel;
    private String dateFormat;
    private String mcAfeeLocaleIdentifier;
    private String mvtLocale;
    private String fallBackLocale;
    private String siebelPrefLang;
    private String privacyURL;
    private boolean doubleByte;

    public MFELocale(String pLocalIdentifier, String pMfeLocale, String pLocaleCode, String pCountryCode,
                     String pDisplayLabel, String pDateFormat, String pMcAfeeLocaleIdentifier, String pMVTLocale,
                     String pFallBackLocale, String siebelPrefLang, String pPrivacyURL, boolean pDoubleByte) {
        super();
        localIdentifier = pLocalIdentifier;
        mfeLocale = pMfeLocale;
        localeCode = pLocaleCode;
        countryCode = pCountryCode;
        displayLabel = pDisplayLabel;
        dateFormat = pDateFormat;
        mcAfeeLocaleIdentifier = pMcAfeeLocaleIdentifier;
        mvtLocale = pMVTLocale;
        fallBackLocale = pFallBackLocale;
        this.siebelPrefLang = siebelPrefLang;
        privacyURL = pPrivacyURL;
        doubleByte = pDoubleByte;
    }

    public void setMFELocale(String mfeLocale) {
        this.mfeLocale = mfeLocale;
    }

    public String getMFELocale() {
        return mfeLocale;
    }

    public void setLocaleCode(String localeCode) {
        this.localeCode = localeCode;
    }

    public String getLocaleCode() {
        return localeCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setDisplayLabel(String displayLabel) {
        this.displayLabel = displayLabel;
    }

    public String getDisplayLabel() {
        return displayLabel;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setLocalIdentifier(String localIdentifier) {
        this.localIdentifier = localIdentifier;
    }

    public String getLocalIdentifier() {
        return localIdentifier;
    }

    public void setMcAfeeLocaleIdentifier(String mcAfeeLocaleIdentifier) {
        this.mcAfeeLocaleIdentifier = mcAfeeLocaleIdentifier;
    }

    public String getMcAfeeLocaleIdentifier() {
        return mcAfeeLocaleIdentifier;
    }

    public void setMVTLocale(String mvtLocale) {
        this.mvtLocale = mvtLocale;
    }

    public String getMVTLocale() {
        return mvtLocale;
    }

    public String getFallBackLocale() {
        return fallBackLocale;
    }


    public void setSiebelPrefLang(String siebelPrefLang) {
        this.siebelPrefLang = siebelPrefLang;
    }

    public String getSiebelPrefLang() {
        return siebelPrefLang;
    }

    public String getPrivacyURL() {
        return privacyURL;
    }

    public void setFallBackLocale(String fallBackLocale) {
        this.fallBackLocale = fallBackLocale;
    }

    public boolean isDoubleByte() {
        return doubleByte;
    }
}
