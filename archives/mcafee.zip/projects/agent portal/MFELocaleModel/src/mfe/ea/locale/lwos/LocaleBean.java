package mfe.ea.locale.lwos;

import java.io.Serializable;

public class LocaleBean implements Serializable {
    public LocaleBean() {
        super();
    }
    private String displayLang;
    private String language;
    private String localeCode;

    public void setDisplayLang(String displayLang) {
        this.displayLang = displayLang;
    }

    public String getDisplayLang() {
        return displayLang;
    }

    public void setLocaleCode(String localeCode) {
        this.localeCode = localeCode;
    }

    public String getLocaleCode() {
        return localeCode;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getLanguage() {
        return language;
    }


    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof LocaleBean)) {
            return false;
        }
        final LocaleBean other = (LocaleBean)object;
        if (!(displayLang == null ? other.displayLang == null : displayLang.equals(other.displayLang))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int PRIME = 37;
        int result = 1;
        result = PRIME * result + ((displayLang == null) ? 0 : displayLang.hashCode());
        return result;
    }
}
