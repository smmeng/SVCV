#export WORKSPACE=/opt/apps/jenkins/jobs/ea.webcenter.spr/workspace
#export WORKSPACE=/home/appsadm/spr/ServicePortal
#cp $WORKSPACE/deploy/ServicePortal_webapp1.ear $WORKSPACE/deploy/ServicePortal.ear
cd /opt/apps/Oracle/Middleware-jdev-11.1.1.6/oracle_common/common/bin/
. ./wlst.sh $WORKSPACE/deployToServer.py
cd $WORKSPACE
