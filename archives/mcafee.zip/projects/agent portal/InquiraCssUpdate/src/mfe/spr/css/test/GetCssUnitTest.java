package mfe.spr.css.test;

import mfe.spr.css.GetCss;


import mfe.spr.css.util.SPRCssUtil;


public class GetCssUnitTest {
    public GetCssUnitTest() {
        super();
    }
    
       
    public static void main_for_local(String[] args) {
        
        try {
//            String env = "";
//            String appName = "";
            
            // local testing
            String env = "dev";
            String appName = "AgentPortal";
            
//            String env = "dev";
//            String appName = "ServicePortal";
            
            
            
            // get css names and write to file
            GetCss getCss = new GetCss(env,appName);
            getCss.execute();
            // get cssFilePathCreated
            String cssFilePathCreated = getCss.getCssFilePathCreated();
            // get javascript version
            String javascriptVersion = getCss.getJavaScriptVersion();
            
            // update css in the db
            CssUpdateTest cssUpdate = new CssUpdateTest(env, appName, cssFilePathCreated, javascriptVersion);
            cssUpdate.execute();
          
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("InquiraCssUpdate encountered error. Program terminated.");
            System.exit(1);;
        }
    }
        
    public static void main(String[] args) {
        
        try {
            String env = "";
            String appName = "";
            
            
            try {
                if(args == null) {
                    throw new Exception("env variable for application url not provided. Specify dev or dev2 or qa or uat or prod to the ant script");
                }
                env = args[0];
            } catch (IndexOutOfBoundsException e) {
                throw new Exception("env variable for application url not provided. Specify dev or dev2 or qa or uat or prod to the ant script");
            }
            
            try {
                // args[1] will be appName i.e (SPR or Agent). If none is specified, default it to SPR
                appName = args[1];
            } catch (IndexOutOfBoundsException e) {
                //default it to SPR
                appName = SPRCssUtil.APP_NAME_SERVICE_PORTAL;
            }
            
            // get css names and write to file
            GetCss getCss = new GetCss(env,appName);
            getCss.execute();
            // get cssFilePathCreated
            String cssFilePathCreated = getCss.getCssFilePathCreated();
            
            String javascriptVersion = getCss.getJavaScriptVersion();
            
            // update css in the db
            CssUpdateTest cssUpdate = new CssUpdateTest(env, appName, cssFilePathCreated, javascriptVersion);
            cssUpdate.execute();
          
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("InquiraCssUpdate encountered error. Program terminated.");
            System.exit(1);
        }
    }
}

