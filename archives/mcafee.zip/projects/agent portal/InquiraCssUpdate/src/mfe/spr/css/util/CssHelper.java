package mfe.spr.css.util;

import java.util.ArrayList;
import java.util.List;


import org.apache.commons.lang3.StringUtils;


public class CssHelper {
    public CssHelper() {
        super();
    }
    
    public static List<String> getLocales() {
        List<String> localeURLs = new ArrayList<String>();
        localeURLs.add("es-MX");
        localeURLs.add("it-IT");
        localeURLs.add("zh-CN");
        localeURLs.add("fr-FR");
        localeURLs.add("pt-BR");
        localeURLs.add("ko-KR");
        localeURLs.add("es-ES");
        localeURLs.add("fr-CA");
        localeURLs.add("nl-NL");
        localeURLs.add("de-DE");
        localeURLs.add("es-US");
        localeURLs.add("ja-JP");
        localeURLs.add("zh-TW");
        localeURLs.add("en-US");
        return localeURLs;
    }
    
    public static List<String> getLocales(String appName) {
        // Agent has only two locales: ja-jp, en-us
        if (StringUtils.isNotEmpty(appName) && appName.equalsIgnoreCase(SPRCssUtil.APP_NAME_AGENT_PORTAL)) {
            List<String> localeURLs = new ArrayList<String>();
             localeURLs.add("ja-JP");
            localeURLs.add("en-US");
            return localeURLs;
        } 
        else {
            return getLocales();
        }
        
    }
    
    public static String determineUserAgentFriendlyName(String userAgent) {
        String userAgentFriendlyName = "";
        if(userAgent.contains("MSIE 10.0")) {
            userAgentFriendlyName = "IE10";
        }
        else if(userAgent.contains("MSIE 9.0")) {
            userAgentFriendlyName = "IE9";
        }
        else if(userAgent.contains("MSIE 8.0")) {
            userAgentFriendlyName = "IE8";
        }
        else if(userAgent.contains("MSIE 7.0")) {
            userAgentFriendlyName = "IE7";
        }
        else if(userAgent.contains("Chrome")) {
            userAgentFriendlyName = "Chrome";
        }
        else if(userAgent.contains("Gecko") || userAgent.contains("Firefox")) {
            userAgentFriendlyName = "FireFox";
        }
        else {
            userAgentFriendlyName = "unknown";
        }
        return userAgentFriendlyName;
    }
}

