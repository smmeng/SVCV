package mfe.spr.css;


import java.io.BufferedReader;
import java.io.FileReader;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import mfe.spr.css.util.SPRCssUtil;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.lang3.StringUtils;


public class CssUpdate {

    private static final String ENGLISH_LOCALE_WITH_UNIQUE_IDENTIFIER = "-en-";
    private static final String ENGLISH_LOCALE = "en";
    private String environment = "dev";
    //private String environment = "dev2";
    //private String environment = "qa";
    //    private String environment = "uat";
    //private String environment = "";

    //    private static String appName= "ServicePortal";
    //    private static String appName= "AgentPortal";

    // only for stand-alone run
    private static String appName = SPRCssUtil.APP_NAME_SERVICE_PORTAL;
    private static String fileName = "C:\\tmp\\InquiraCSS\\ServicePortal_dev_inquiracss.txt";

    // only for stand-alone run
    //    private static String appName= SPRCssUtil.APP_NAME_AGENT_PORTAL;
    //    private static String fileName = "C:\\tmp\\InquiraCSS\\AgentPortal_dev_inquiracss.txt";

    private String javascriptVersion;

    public CssUpdate() {
        super();
    }

    public CssUpdate(String environment, String appName, String fileName, String javascriptVersion) {
        this.environment = environment;
        this.appName = appName;
        this.fileName = fileName;
        this.javascriptVersion = javascriptVersion;
    }


    public static class CSSFileVersion {
        String appName;
        String locale;
        String browser;
        String URLPart;
        String fileType;

        CSSFileVersion() {
            super();
        }

        public void setLocale(String locale) {
            this.locale = locale;
        }

        public String getLocale() {
            return locale;
        }

        public void setBrowser(String browser) {
            this.browser = browser;
        }

        public String getBrowser() {
            return browser;
        }

        public void setAppName(String appName) {
            this.appName = appName;
        }

        public String getAppName() {
            return appName;
        }

        public void setURLPart(String URLPart) {
            this.URLPart = URLPart;
        }

        public String getURLPart() {
            return URLPart;
        }

        public void setFileType(String fileType) {
            this.fileType = fileType;
        }

        public String getFileType() {
            return fileType;
        }

        public String toString() {
            return appName + "::" + locale + "::" + browser + "::" + URLPart + "::" + fileType;
        }
    }

    public static class LocalBrowser {
        String locale;
        String browser;

        LocalBrowser() {
            super();
        }

        public void setLocale(String locale) {
            this.locale = locale;
        }

        public String getLocale() {
            return locale;
        }

        public void setBrowser(String browser) {
            this.browser = browser;
        }

        public String getBrowser() {
            return browser;
        }
    }

    public Connection getSimpleConnection() {
        Connection conn = null;
        long l = System.currentTimeMillis();
        try {
            DbUtils.loadDriver("oracle.jdbc.OracleDriver");
            if (environment.equals("dev") || environment.equals("dev2")) {
                conn =
DriverManager.getConnection("jdbc:oracle:thin:@DNVDEVDBINQ1:1521/devinq", "inquiraim", "InfoMngr_PR0D");
            } else if (environment.equals("qa")) {
                conn =
DriverManager.getConnection("jdbc:oracle:thin:@dnvqadbinq1.corp.nai.org:1521/qainq", "inquiraim", "InfoMngr_PR0D");
            } else if (environment.equals("uat")) {
                conn =
DriverManager.getConnection("jdbc:oracle:thin:@//inqstg-scan.corp.nai.org:1521/stginq", "inquiraim", "InfoMngr_stg");
            } else if (environment.equals("prod")) {
                conn =
DriverManager.getConnection("jdbc:oracle:thin:@//inqdb-scan.corp.nai.org:1521/prdinq", "inquiraim", "InfoMngr_PR0D");
            }
            conn.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
            DbUtils.closeQuietly(conn);
        }
        return conn;
    }

    public static void main(String[] args) {
        BufferedReader bf = null;
        Connection orclConn = null;
        CssUpdate cu = new CssUpdate();
        try {
            cu.execute();
            //            System.out.println("language code="+cu.getLanguageCode(""));
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
    }

    public void execute() {
        System.out.println(" \n**************** Starting Css Update in DB ***************** ");
        System.out.println("AppName=" + appName + " :: environment=" + environment + " :: reading from css file=" +
                           fileName);
        boolean isAgentPortal = SPRCssUtil.APP_NAME_AGENT_PORTAL.equalsIgnoreCase(appName);

        List<CssUpdate.LocalBrowser> lbList = new ArrayList<CssUpdate.LocalBrowser>();
        BufferedReader bf = null;
        Connection orclConn = null;
        try {
            orclConn = getSimpleConnection();
            if (orclConn != null) {
                getLocaleBrowserList(orclConn, appName, lbList);

                //Read the file
                bf = new BufferedReader(new FileReader(fileName));
                String lineRead = null;
                Map<String, Map<String, CSSFileVersion>> outputMap =
                    new HashMap<String, Map<String, CSSFileVersion>>();
                Map<String, CSSFileVersion> cssVersions = null;
                while ((lineRead = bf.readLine()) != null) {
                    if (lineRead != null) {
                        lineRead = lineRead.trim();
                        if (!lineRead.contains("2.css")) {
                            for (CssUpdate.LocalBrowser lb : lbList) {
                                // agent portal css names do not have ja-JP format. they only have language code.
                                // so, looking for language code too. otherwise ja-JP are getting missed out in the update
                                // latter condition applies only to agent portal
                                if (lineRead.contains(lb.getLocale()) ||
                                    (isAgentPortal && lineRead.contains(getLanguageCode(lb.getLocale())))) {
                                    //                                if(lineRead.contains(lb.getLocale())){
                                    String b = null;
                                    if (lb.getBrowser().equals("gecko") && lineRead.contains("gecko")) {
                                        b = "gecko";
                                    } else if (lb.getBrowser().equals("webkit") && lineRead.contains("webkit")) {
                                        b = "webkit";
                                    } else if (lb.getBrowser().equals("ie-7.0") && lineRead.contains("ie-7.0")) {
                                        b = "ie-7.0";
                                    } else if (lb.getBrowser().equals("ie-8.0") && lineRead.contains("ie-8.0")) {
                                        b = "ie-8.0";
                                    } else if (lb.getBrowser().equals("ie-9.0") && lineRead.contains("ie-9.0")) {
                                        b = "ie-9.0";
                                    } else {
                                        continue;
                                    }

                                    StringBuffer sb = new StringBuffer(lineRead);
                                    if (lb.getBrowser().contains("ie")) {
                                        sb.append(":::");
                                        sb.append(lineRead.substring(0, lineRead.indexOf(".css"))).append("2.css");
                                    }

                                    if (!outputMap.containsKey(b)) {
                                        cssVersions = new HashMap<String, CSSFileVersion>();
                                        outputMap.put(b, cssVersions);
                                    } else {
                                        cssVersions = outputMap.get(b);
                                    }

                                    if (!cssVersions.containsKey(sb.toString())) {
                                        CSSFileVersion version = new CSSFileVersion();
                                        version.setAppName(appName);
                                        version.setBrowser(b);
                                        // Raju- Fix for 'en' locale issue. See method javadoc for more details
                                        if (lb.getLocale().equalsIgnoreCase(ENGLISH_LOCALE_WITH_UNIQUE_IDENTIFIER)) {
                                            removeUniqueIdentifierForEnglishLocaleBeforeTableUpdate(lb);
                                        }

                                        version.setLocale(lb.getLocale());
                                        version.setURLPart(sb.toString());
                                        cssVersions.put(sb.toString(), version);
                                    }

                                }
                            }
                        }
                    }
                }
                if (outputMap != null) {
                    // add javascriptVersion to update
                    addJavaScriptVersion(outputMap);
                    printAndUpdateTable(orclConn, outputMap);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                orclConn.rollback();
            } catch (SQLException f) {
                f.printStackTrace();
            }
        } finally {
            if (bf != null) {
                try {
                    bf.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            DbUtils.closeQuietly(orclConn);
        }
        System.out.println(" **************** Css Update completed in DB ***************** ");
    }


    private static void updateTable(Connection orclConn, CSSFileVersion version) throws SQLException {
        PreparedStatement prepstmt;
        ResultSet orclRs;
        StringBuffer queryBuffer;
        prepstmt = null;
        orclRs = null;
        if (version.getFileType() != null && "js".equals(version.getFileType())) {
            queryBuffer =
                    new StringBuffer("UPDATE MFE_SPR_STATIC_FILE_VER SET URL_PART=?, UPDATED_ON=?,UPDATED_BY=? WHERE FILE_TYPE = ? AND APP_NAME=?");
            //            queryBuffer = new StringBuffer("UPDATE JPTEST SET URL_PART=?, UPDATED_ON=?,UPDATED_BY=? WHERE FILE_TYPE = ?");
            prepstmt = orclConn.prepareStatement(queryBuffer.toString());
            prepstmt.setString(1, version.getURLPart());
            prepstmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            prepstmt.setString(3, "admin-ant");
            prepstmt.setString(4, version.getFileType());
            prepstmt.setString(5, "ServicePortal");
        } else {
            queryBuffer =
                    new StringBuffer("UPDATE MFE_SPR_STATIC_FILE_VER SET URL_PART=?, UPDATED_ON=?,UPDATED_BY=? WHERE LOCALE = ? AND BROWSER_TYPE=? AND APP_NAME=?");
            //            queryBuffer = new StringBuffer("UPDATE JPTEST SET URL_PART=?, UPDATED_ON=?,UPDATED_BY=? WHERE LOCALE = ? AND BROWSER_TYPE=? AND APP_NAME=?");
            prepstmt = orclConn.prepareStatement(queryBuffer.toString());
            prepstmt.setString(1, version.getURLPart());
            prepstmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            prepstmt.setString(3, "admin-ant");
            prepstmt.setString(4, version.getLocale());
            prepstmt.setString(5, version.getBrowser());
            prepstmt.setString(6, version.getAppName());
        }

        int opt = prepstmt.executeUpdate();
        if (opt > 0)
            orclConn.commit();
        prepstmt.close();
    }

    private static void printAndUpdateTable(Connection orclConn,
                                            Map<String, Map<String, CSSFileVersion>> outputMap) throws SQLException {
        System.out.println(" \n**************** printAndUpdateTable started ***************** ");
        Iterator iter = outputMap.entrySet().iterator();
        int totalCssFileNamesUpdated = 0;
        while (iter.hasNext()) {
            Map.Entry pairs = (Map.Entry)iter.next();
            System.out.println("-----------------------------------------------");
            System.out.println(pairs.getKey());
            Iterator iter2 = ((Map<String, CSSFileVersion>)pairs.getValue()).entrySet().iterator();
            CSSFileVersion versions = null;
            int count = 0;
            while (iter2.hasNext()) {
                Map.Entry pairs2 = (Map.Entry)iter2.next();
                versions = (CSSFileVersion)pairs2.getValue();
                System.out.println(versions.getLocale() + " ---> " + versions.getURLPart());
                updateTable(orclConn, versions);
                ++count;
                ++totalCssFileNamesUpdated;
            }
            System.out.println("Count: " + count);
            System.out.println("-----------------------------------------------");
        }
        System.out.println("Total Css files names updated in DB=" + totalCssFileNamesUpdated);
        System.out.println(" \n**************** printAndUpdateTable completed ***************** ");
    }

    private static void getLocaleBrowserList(Connection orclConn, String appName,
                                             List<CssUpdate.LocalBrowser> lbList) {
        System.out.println(" \n**************** getLocaleBrowserList started ***************** ");
        PreparedStatement prepstmt = null;
        ResultSet orclRs = null;
        StringBuffer queryBuffer =
            new StringBuffer("SELECT LOCALE, BROWSER_TYPE FROM MFE_SPR_STATIC_FILE_VER WHERE APP_NAME=?");
        //        StringBuffer queryBuffer = new StringBuffer("SELECT LOCALE, BROWSER_TYPE FROM JPTEST WHERE APP_NAME=?");
        try {
            prepstmt = orclConn.prepareStatement(queryBuffer.toString());
            prepstmt.setString(1, appName);
            orclRs = prepstmt.executeQuery();
            while (orclRs.next()) {
                CssUpdate.LocalBrowser lb = new CssUpdate.LocalBrowser();
                lb.setBrowser(orclRs.getString("BROWSER_TYPE"));
                lb.setLocale(orclRs.getString("LOCALE"));
                if (lb.getBrowser() != null && lb.getLocale() != null) {
                    // Raju- Fix for 'en' locale issue. See method javadoc for more details
                    if (lb.getLocale().equalsIgnoreCase(ENGLISH_LOCALE)) {
                        addUniqueIdentifierForEnglishLocaleRetrievedFromDB(lb); //change it like this: '-en-'
                    }

                    lbList.add(lb);
                    //                    System.out.println("locale="+lb.getLocale() + "::browser="+lb.getBrowser());
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                orclConn.rollback();
            } catch (SQLException f) {
                f.printStackTrace();
            }
        } finally {
            DbUtils.closeQuietly(orclRs);
        }
        System.out.println("Total locale browser entries =" + lbList.size());
        System.out.println(" \n**************** getLocaleBrowserList completed ***************** ");
    }


    // get language code from locale ex: ja-JP

    public String getLanguageCode(String locale) {
        String languageCode = null;
        if (StringUtils.isNotEmpty(locale)) {
            StringTokenizer localeTokens = new StringTokenizer(locale.trim(), "-");
            if (localeTokens != null && localeTokens.countTokens() > 0) {
                languageCode = localeTokens.nextToken();
            }

        }
        return languageCode;
    }

    // There is a javascript version number that need to be updated in the DB. This method adds the javascript version
    // to the already existing outputMap

    public void addJavaScriptVersion(Map<String, Map<String, CSSFileVersion>> outputMap) {
        boolean isAgentPortal = SPRCssUtil.APP_NAME_AGENT_PORTAL.equalsIgnoreCase(appName);
        //Only ServicePortal has a version number for javascript, agent does not.
        if (!isAgentPortal) {
            Map<String, CSSFileVersion> cssVersions = new HashMap<String, CSSFileVersion>();
            CSSFileVersion version = new CSSFileVersion();
            version.setAppName(appName);
            version.setBrowser(null);
            version.setLocale(null);
            version.setURLPart(javascriptVersion);
            version.setFileType("js");
            cssVersions.put("javascriptVersion", version);
            outputMap.put("javascriptVersion", cssVersions);
            System.out.println("Added javascriptVersion: " + javascriptVersion + " to update in  the DB");
        }

    }

    /* Raju-Defect fix: Ex: portal_zh-TW-desktop-enjigy-zh_TW-ltr-ie-8.0-windows.css
     * Even though it is a chinese locale css, because of the presence of 'en' inside css name,
     *  the update part of the code gets tricked and assumes the below css name to be 'en' locale and makes an incorrect update on the table column.
     * So, adding unique identifier for 'en' to fix the issue mentioned.
     * Ex: see 'en' inside this css name==>portal_zh-TW-desktop-enjigy-zh_TW-ltr-ie-8.0-windows.css
     */

    public static void addUniqueIdentifierForEnglishLocaleRetrievedFromDB(CssUpdate.LocalBrowser lb) {
        if (lb.getLocale().equalsIgnoreCase(ENGLISH_LOCALE)) {
            lb.setLocale(ENGLISH_LOCALE_WITH_UNIQUE_IDENTIFIER); // change it like this: '-en-'
        }
    }

    /* Raju-Defect fix: Before updating the table the english locale value has to be reset to 'en'
     * Remove the unique identifier '-en-' and reset to 'en'
     *
    */

    public void removeUniqueIdentifierForEnglishLocaleBeforeTableUpdate(CssUpdate.LocalBrowser lb) {
        if (lb.getLocale().equalsIgnoreCase(ENGLISH_LOCALE_WITH_UNIQUE_IDENTIFIER)) {
            lb.setLocale(ENGLISH_LOCALE); // reset it back to 'en'
        }
    }
}
