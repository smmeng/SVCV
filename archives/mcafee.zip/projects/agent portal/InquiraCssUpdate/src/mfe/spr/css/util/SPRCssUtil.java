package mfe.spr.css.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;


public class SPRCssUtil {
    
    public static String APP_NAME_SERVICE_PORTAL = "ServicePortal";
    public static String APP_NAME_AGENT_PORTAL = "AgentPortal";
    
    public SPRCssUtil() {
        super();
    }
    
    /*
     *  Utility method to find the deleteImgIconId used in two use cases. 1. EditRole, 2. DeleteRole
     */
    public static String findDeleteImgIconId(String roleId, String roleName, String deleteImgIconIdSuffix) {
        // roleId:pt1:r5:0:roles:2:it16
        // deleteImgIconId = pt1:r5:0:roles:2:cil1::icon
        System.out.println(new Date() + " " + " finding deleteImgIconId of " + roleName);
        String deleteImgIconId = "";
        if(roleId != null && !roleId.equals("")) {
            deleteImgIconId = roleId.substring(0, roleId.lastIndexOf(":"));
            System.out.println(new Date() + " " + " deleteImgIconId id= " + deleteImgIconId);
            deleteImgIconId = deleteImgIconId + deleteImgIconIdSuffix;
            System.out.println(new Date() + " " + " final deleteImgIconId id= " + deleteImgIconId);
        }
        return deleteImgIconId;
    }
    
    public static String getCurrentTimeStamp() {
        DateFormat df = new SimpleDateFormat("yyyyMMdd_hhmmss");
        return df.format(new Date());
    }
    
    public static String writeToFile(String fileName, List<String> cssFileNames) {
            String filePath = null;
            BufferedWriter bw = null;
            try {
                filePath = createFile(fileName);
                bw = new BufferedWriter(new FileWriter(new File(filePath)));
                // writing to file
                for(String cssFileName: cssFileNames) {
                        bw.write(cssFileName);
                        bw.newLine();
                }
            } catch(IOException ie) {
                ie.printStackTrace();;
            } catch(Exception ie) {
                ie.printStackTrace();
            }finally {
                if(bw != null) {
                try {
                    bw.close();
                } catch (IOException ioe) {
                    // TODO: Add catch code
                    ioe.printStackTrace();
                } 
                }
                
            }
            System.out.println("File created at="+filePath);
            return filePath;
        }
    
    public static String writeToFile(String fileName, List<String> cssFileNames, String fromJavaClientOrSelenium) {
            if (fromJavaClientOrSelenium == null) {
                fromJavaClientOrSelenium = "fromSelenium";
            }
            String filePath = null;
            BufferedWriter bw = null;
            try {
                filePath = createFile(fileName);
                bw = new BufferedWriter(new FileWriter(new File(filePath)));
                // writing to file
                for(String cssFileName: cssFileNames) {
                        bw.write(cssFileName);
                        bw.newLine();
                }
            } catch(IOException ie) {
                ie.printStackTrace();
            } catch(Exception ie) {
                ie.printStackTrace();
            }finally {
                if(bw != null) {
                try {
                    bw.close();
                } catch (IOException ioe) {
                    // TODO: Add catch code
                    ioe.printStackTrace();
                } 
                }
                
            }
            System.out.println("File created at="+filePath);
            return filePath;
        }
    
    /*
     *  Get the absolute file path of the given file name. make sure file exists in the project root
     */
    public static String getAbsoluteFilePathOf(String fileName) {
        String filePath = new File(".").getAbsolutePath();
        filePath = isWindows()? filePath.substring(0,filePath.lastIndexOf("\\.")):
                        filePath.substring(0,filePath.lastIndexOf("/."));    
        String filePathSuffix = "/"+fileName;
        // System.out.println("filePathSuffix="+filePathSuffix);
        
        // for windows
        if(isWindows()) {
            filePathSuffix = filePathSuffix.replaceAll("/", "\\\\\\\\");
            filePath = filePath.replaceAll("\\\\", "\\\\\\\\");
        }
        
        System.out.println("Absolute file path="+filePath+filePathSuffix);
        return filePath+filePathSuffix;
    }
    
    public static boolean isWindows() {
        boolean isWindows = false;
        String os = getOS();
//        System.out.println("system env: OS="+os);
        if(!StringUtils.isEmpty(os)) {
            isWindows = os.toLowerCase().contains("windows");
        }
        return isWindows;
    }
    
    public static String getOS() {
        return System.getenv("os");
    }
    
    public static String getCurrentWorkingDirPath() throws Exception{
        String currentWorkingDirPath =  new File(".").getAbsolutePath();
        if (StringUtils.isNotEmpty(currentWorkingDirPath)) {
            // C:\SPRSelenium\FunctionalTests\.
            currentWorkingDirPath = currentWorkingDirPath.substring(0, currentWorkingDirPath.length()-1);
        }
        System.out.println("classloader.getResource.getPath()="+new SPRCssUtil().getClass().getClassLoader().getResource("").getPath());
        return currentWorkingDirPath;
    }
    
    public static void main(String[] args) {
        System.out.println("Test " + getCurrentTimeStamp());
//        getAbsoluteFilePathOf("submit_sample_infected.zip");
        List<String> cssFileNames = new ArrayList<String>();
        cssFileNames.add("One");
        cssFileNames.add("Two");
//writeToFile("firefox.txt", cssFileNames); 
//        createFile("firefox.txt");
        try {
            System.out.println("Current working dir: " +
                               getCurrentWorkingDirPath());
        } catch (Exception e) {
            // TODO: Add catch code
            e.printStackTrace();
        }
    }
    
    public static String createFile(String fileName) throws Exception{
        String filePathCreated = createNewFile(createParentDir(),fileName);
        return filePathCreated;
        
    }
    
    public static String createParentDir() throws Exception{
        String parentDirPath = "C:/tmp/InquiraCSS/";
        if(!isWindows()) {
            // for mac??
            parentDirPath = "/tmp/InquiraCSS/";
        }
        File file = new File(parentDirPath);
        file.mkdirs();
        return parentDirPath;
    }
    
    public static String createNewFile(String parentDirPath, String fileName) throws Exception{
        File file = new File(parentDirPath+fileName);
        if(!file.exists()) {
        //                file1.mkdirs();
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return parentDirPath+fileName;
    }
    
}

