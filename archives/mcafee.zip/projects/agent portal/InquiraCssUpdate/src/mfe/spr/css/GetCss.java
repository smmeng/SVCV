package mfe.spr.css;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import mfe.spr.css.util.CssHelper;
import mfe.spr.css.util.SPRCssUtil;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;


public class GetCss {
    private static int loginSocketTimeOut = 50000;
    private static int loginConnectionTimeOut = 50000;
    private static int loginMaxTotal = 20000;
    private static int loginMaxPerRoute = 5000;

    private List<String> cssFileNames = new ArrayList<String>();
    private String userAgent;
    private String env;
    private String appName;
    private String cssFilePathCreated;
    private String javaScriptVersion;

    // ServicePortal application urls
    //    private String[] devUrls = {"https://support-dev.corp.nai.org/ServicePortal/faces/wcnav_defaultSelection"};
    private String[] devUrls = { "http://dnvdevappepp1.corp.nai.org:1411/ServicePortal/faces/wcnav_defaultSelection" };

    private String[] dev2Urls =
    { "http://dnvdev2appepp1.corp.nai.org:10003/ServicePortal/faces/wcnav_defaultSelection" };

    private String[] qaUrls =
    { "http://dnvqaappepp1.corp.nai.org:9007/ServicePortal/faces/wcnav_defaultSelection", "http://dnvqaappepp2.corp.nai.org:9007/ServicePortal/faces/wcnav_defaultSelection" };

    private String[] uatUrls =
    { "http://dnvstgappowc3.corp.nai.org:9007/ServicePortal/faces/wcnav_defaultSelection", "http://dnvstgappowc4.corp.nai.org:9007/ServicePortal/faces/wcnav_defaultSelection" };

    private String[] prodUrls =
    { "http://dnvappowc3.corp.nai.org:9007/ServicePortal/faces/wcnav_defaultSelection", "http://dnvappowc4.corp.nai.org:9007/ServicePortal/faces/wcnav_defaultSelection" };

    // AgentPortal application urls
    //    private String[] agentDevUrls = {"https://agent-dev.corp.nai.org/AgentPortal/faces/wcnav_defaultSelection"};
    // Agent Portal css build was failing on 11/19/2013. As per the email from Abhi, this is the new url
    //    private String[] agentDevUrls = {"https://agent-dev.corp.nai.org/AgentPortal/faces/login"};
    private String[] agentDevUrls =
    { "http://dnvdevappepp4.corp.nai.org:7006/AgentPortal/faces/wcnav_defaultSelection" };


    private String[] agentQaUrls =
    { "http://dnvqaappepp4.corp.nai.org:7005/AgentPortal/faces/wcnav_defaultSelection", "http://dnvqaappepp5.corp.nai.org:7005/AgentPortal/faces/wcnav_defaultSelection" };

    private String[] agentUatUrls =
    { "http://dnvstgappowc5.corp.nai.org:7006/AgentPortal/faces/wcnav_defaultSelection",
      "http://dnvstgappowc6.corp.nai.org:7006/AgentPortal/faces/wcnav_defaultSelection" };

    private String[] agentProdUrls =
    { "http://dnvappowc5.corp.nai.org:7006/AgentPortal/faces/wcnav_defaultSelection", "http://dnvappowc6.corp.nai.org:7006/AgentPortal/faces/wcnav_defaultSelection" };

    private String[] baseUrls = { "" };

    // LoadBalanced urls
    private String baseUrl = "https://support-dev.corp.nai.org/ServicePortal/faces/wcnav_defaultSelection";
    private String devUrl = "https://support-dev.corp.nai.org/ServicePortal/faces/wcnav_defaultSelection";
    private String dev2Url = "https://support-dev2.corp.nai.org/ServicePortal/faces/wcnav_defaultSelection";
    private String qaUrl = "https://support-qa.corp.nai.org/ServicePortal/faces/wcnav_defaultSelection";
    private String uatUrl = "https://support-uat.mcafee.com/ServicePortal/faces/wcnav_defaultSelection";
    private String prodUrl = "https://support-beta.mcafee.com/ServicePortal/faces/wcnav_defaultSelection";

    private String agentDevUrl = "https://agent-dev.corp.nai.org/AgentPortal/faces/wcnav_defaultSelection";
    private String agentQaUrl = "https://agent-qa.corp.nai.org/AgentPortal/faces/wcnav_defaultSelection";
    private String agentUatUrl = "https://agent-uat.mcafee.com/AgentPortal/faces/wcnav_defaultSelection";
    private String agentProdUrl = "https://agent.mcafee.com/AgentPortal/faces/wcnav_defaultSelection";


    public GetCss() {
        super();
    }

    public GetCss(String env) throws Exception {
        this.env = env;
        determineAppURLBasedOnEnv();
    }

    /* Right now we have run the inquira css for two diff apps SPR, Agent portal */

    public GetCss(String env, String appName) throws Exception {
        this.env = env;
        this.appName = appName;
        determineAppURLBasedOnEnv();
    }

    public static void main(String[] args) {
        GetCss css = new GetCss();
        try {
            String ie10 = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)";
            String ie9 = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/6.0)";
            String ie8 = "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/6.0)";
            String ie7 = "Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/6.0)";
            String firefox = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0";
            String chrome =
                "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36";
            String userAgent = firefox;
            //            css.getCSSForAllSupportedBrowsers(firefox, chrome, ie7, ie8, ie9);
            //            css.getCSSForAllSupportedBrowsers(ie7);
            //            css.getCSSForAllSupportedBrowsers(chrome,firefox);
            //            css.willWork(css.getBaseUrl(), userAgent, "en-US");
            css.getJavaScriptVersion(css.agentDevUrl, userAgent, "en-US");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void execute() throws Exception {
        try {
            // we got to generate the css for all the nodes in a cluster
            int nodeCount = 0;
            for (String individualNodeUrl : baseUrls) {
                this.baseUrl = individualNodeUrl;
                System.out.println("\nConnecting to " + appName + " " + env + " node " + ++nodeCount);
                getCSSForAllSupportedBrowsers(loadUserAgents());

                // get javascript version # from any userAgent and any locale
                String firefox = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0";
                this.javaScriptVersion = getJavaScriptVersion(getBaseUrl(), firefox, "en-US");
            }

        } catch (Exception e) {
            //            e.printStackTrace();
            throw e;
        }
    }

    public void determineAppURLBasedOnEnv() throws Exception {
        if (env.toLowerCase().equals("dev")) {
            baseUrls = devUrls;
            if (isAgentPortal()) {
                baseUrls = agentDevUrls;
            }
        } else if (env.toLowerCase().equals("dev2")) {
            baseUrls = dev2Urls;
            if (isAgentPortal()) {
                baseUrls = agentDevUrls;
            }
        } else if (env.toLowerCase().equals("qa")) {
            baseUrls = qaUrls;
            if (isAgentPortal()) {
                baseUrls = agentQaUrls;
            }
        } else if (env.toLowerCase().equals("uat") || env.toLowerCase().equals("stage")) {
            baseUrls = uatUrls;
            if (isAgentPortal()) {
                baseUrls = agentUatUrls;
            }
        } else if (env.toLowerCase().equals("prod")) {
            baseUrls = prodUrls;
            if (isAgentPortal()) {
                baseUrls = agentProdUrls;
            }
        } else { // could not figure out env. so going to dev or throw exception
            baseUrls = devUrls;
        }
        System.out.println("envronment=" + env);
        if (baseUrls != null) {
            System.out.println("application node urls in cluster=" + baseUrls.length);

        } else {
            throw new Exception("Application urls turned out to be null in environment=" + env);
        }
    }


    public boolean isAgentPortal() {
        return (StringUtils.isNotEmpty(appName) && appName.equalsIgnoreCase(SPRCssUtil.APP_NAME_AGENT_PORTAL));
    }

    public String[] loadUserAgents() {
        String ie10 = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)";
        String ie9 = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/6.0)";
        String ie8 = "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/6.0)";
        String ie7 = "Mozilla/5.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/6.0)";
        String firefox = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0";
        String chrome =
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36";
        String[] allSupportedUserAgents = { firefox, chrome, ie7, ie8, ie9 };
        //        String[] allSupportedUserAgents = {ie8}; // for unit testing only
        return allSupportedUserAgents;
    }

    public void getCSSForAllSupportedBrowsers(String... listOfSupportedUserAgents) throws Exception {
        for (String userAgent : listOfSupportedUserAgents) {
            getCssFor(userAgent, getBaseUrl());
        }
        System.out.println("cssfiles count=" + cssFileNames.size());
        String firefox = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0";
        cssFilePathCreated = SPRCssUtil.writeToFile(appName + "_" + env + "_inquiracss.txt", cssFileNames);
    }

    public void getCssFor(String userAgent, String baseUrl) throws Exception {
        //        GetCss getCss = new GetCss();
        String userAgentFriendlyName = CssHelper.determineUserAgentFriendlyName(userAgent);
        System.out.println("Connecting to " + baseUrl);
        System.out.println("*******************  " + userAgentFriendlyName + "  START  *********************");
        int count = 0;
        for (String locale : CssHelper.getLocales(appName)) {
            //            ++count;
            try {
                willWork(baseUrl, userAgent, locale);
                ++count;
            } catch (Exception e) {
                e.printStackTrace();
                throw e;
            }
        }
        System.out.println(userAgentFriendlyName + " css files=" + count);
        //        SPRSeleniumUtil.writeToFile(userAgentFriendlyName+".txt", getCss.getCssFileNames());
        System.out.println("*******************  " + userAgentFriendlyName + "   END *********************");
        System.out.println("*******************   END *********************");
    }

    private void willWork(String baseUrl, String userAgent, String locale) throws Exception {
        // Create an instance of HttpClient.
        HttpClient httpclient = getHttpClient();
        CookieStore cookieStore = new BasicCookieStore();
        HttpContext localContext = new BasicHttpContext();
        localContext.setAttribute(ClientContext.COOKIE_STORE, cookieStore);
        HttpGet httpget = new HttpGet(baseUrl);
        httpget.setHeader("User-Agent", userAgent);
        httpget.setHeader("Cookie", "testing=test");
        HttpResponse postResponse = httpclient.execute(httpget, localContext);
        //        System.out.println(postResponse.getStatusLine());
        HttpEntity entity = postResponse.getEntity();
        if (entity != null) {
            String response = EntityUtils.toString(entity);
            String afrLoop = response.replaceAll("(?s).*(_afrLoop=\\d+).*", "$1");
            if (locale == null) {
                locale = "";
            } else {
                locale = "&lang=" + locale;
            }
            HttpGet bigGet = new HttpGet(baseUrl + "?" + afrLoop + "&_afrWindowMode=0&_afrWindowId=null" + locale);
            bigGet.setHeader("User-Agent", userAgent);
            bigGet.setHeader("Cookie", "testing=test");
            HttpResponse bigResponse = httpclient.execute(bigGet, localContext);
            //            System.out.println(bigResponse.getStatusLine());
            HttpEntity entity1 = bigResponse.getEntity();
            String response1 = EntityUtils.toString(entity1);
            //            System.out.println(response1);
            Pattern cssPattern = Pattern.compile("(portal[^\"]+\\.css)\"");
            Matcher m = cssPattern.matcher(response1);
            String fullCss = "";
            while (m.find()) {
                if (fullCss.length() == 0) {
                    fullCss = m.group(1);
                }
                //                else {
                //                    fullCss += ":::" + m.group(1);
                //                }
            }
            if (StringUtils.isEmpty(fullCss)) {
                throw new Exception("Css file name retrieved is empty. Is the application down? Check the application url:" +
                                    baseUrl);
            }
            System.out.println(fullCss);
            cssFileNames.add(fullCss);
        }

    }

    // Get java script version. Only ServicePortal has a version number for javascript, agent does not.

    private String getJavaScriptVersion(String baseUrl, String userAgent, String locale) throws Exception {
        // AgentPortal will not have a javascript version number. Only SPR has javascript version
        if (!isAgentPortal()) {
            System.out.println("********** Getting javascript version Start ********** ");
            System.out.println("Connecting to " + baseUrl);
            // Create an instance of HttpClient.
            HttpClient httpclient = getHttpClient();
            CookieStore cookieStore = new BasicCookieStore();
            HttpContext localContext = new BasicHttpContext();
            localContext.setAttribute(ClientContext.COOKIE_STORE, cookieStore);
            HttpGet httpget = new HttpGet(baseUrl);
            httpget.setHeader("User-Agent", userAgent);
            httpget.setHeader("Cookie", "testing=test");
            HttpResponse postResponse = httpclient.execute(httpget, localContext);
            //        System.out.println(postResponse.getStatusLine());
            HttpEntity entity = postResponse.getEntity();
            if (entity != null) {
                String response = EntityUtils.toString(entity);
                String afrLoop = response.replaceAll("(?s).*(_afrLoop=\\d+).*", "$1");
                if (locale == null) {
                    locale = "";
                } else {
                    locale = "&lang=" + locale;
                }
                HttpGet bigGet = new HttpGet(baseUrl + "?" + afrLoop + "&_afrWindowMode=0&_afrWindowId=null" + locale);
                bigGet.setHeader("User-Agent", userAgent);
                bigGet.setHeader("Cookie", "testing=test");
                HttpResponse bigResponse = httpclient.execute(bigGet, localContext);
                //            System.out.println(bigResponse.getStatusLine());
                HttpEntity entity1 = bigResponse.getEntity();
                String response1 = EntityUtils.toString(entity1);
                //            System.out.println(response1);
                Pattern cssPattern = Pattern.compile("(jquery-\\d+.\\d+.\\d+.min[^\"]+\\.js)\"");
                Matcher m = cssPattern.matcher(response1);
                String fullJSName = "";
                while (m.find()) {
                    if (fullJSName.length() == 0) {
                        fullJSName = m.group(1);
                    }
                    //                else {
                    //                    fullCss += ":::" + m.group(1);
                    //                }
                }
                if (StringUtils.isEmpty(fullJSName)) {
                    throw new Exception("fullJSName name retrieved is empty. Is the application down? Check the application url:" +
                                        baseUrl);
                }
                System.out.println(fullJSName);
                // grab the version # from _ to the .  (ex: jquery-1.7.1.min_13296-d647855352b1.js)
                // js version should be _13296-d647855352b1
                int indexOfJQueryMinUnderscore = fullJSName.lastIndexOf("min_") + 3;
                this.javaScriptVersion = fullJSName.substring(indexOfJQueryMinUnderscore, fullJSName.indexOf(".js"));
                System.out.println(javaScriptVersion);
                System.out.println("********** Getting javascript version End ********** ");
                //            cssFileNames.add(fullCss);
            }


        }

        return javaScriptVersion;

    }

    public String getCssFileName(HttpClient httpclient) {
        return "";
    }

    public static org.apache.http.client.HttpClient getHttpClient() throws NoSuchAlgorithmException,
                                                                           KeyManagementException {
        SSLContext ctx = SSLContext.getInstance("TLS");
        X509TrustManager tm = new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
            }

            public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
            }

            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        };
        ctx.init(null, new TrustManager[] { tm }, null);
        SSLSocketFactory sslSF = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("http", 80, PlainSocketFactory.getSocketFactory()));
        schemeRegistry.register(new Scheme("https", 443, sslSF));
        PoolingClientConnectionManager cm = new PoolingClientConnectionManager(schemeRegistry);
        cm.setMaxTotal(loginMaxTotal);
        cm.setDefaultMaxPerRoute(loginMaxPerRoute);
        DefaultHttpClient httpClient = new DefaultHttpClient(cm);
        /*
                 * Initialize the timeouts
                 */
        httpClient.getParams().setParameter(CoreConnectionPNames.TCP_NODELAY, true);
        httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, loginConnectionTimeOut);
        httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, loginSocketTimeOut);

        httpClient.setRedirectStrategy(new LaxRedirectStrategy());
        return httpClient;
    }

    public void setCssFileNames(List<String> cssFileNames) {
        this.cssFileNames = cssFileNames;
    }

    public List<String> getCssFileNames() {
        return cssFileNames;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppName() {
        return appName;
    }

    public String getCssFilePathCreated() {
        return cssFilePathCreated;
    }

    public String getJavaScriptVersion() {
        return javaScriptVersion;
    }
}

