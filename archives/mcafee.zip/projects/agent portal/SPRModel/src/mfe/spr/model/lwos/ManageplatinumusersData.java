package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfContactAdministration;
import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.platinumportalws.contactadministration.ContactAdministration;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;


//import mfe.spr.proxy.elite.EServiceLiteWSProxy;


//import oracle.jbo.SortCriteria;

public class ManageplatinumusersData {
    private static final String className = ManageplatinumusersData.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(ManageplatinumusersData.class);
    private Map<Integer, ContactAdministration> mData = new LinkedHashMap<Integer, ContactAdministration>();
    private int fetchedSize;
    private int wsTotalRecordCount;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private String sessionLogin;
    private int fetchSize;
    private String wsdlURL;
    private int rangeStartIndex;
    private String searchSpec;

    public ManageplatinumusersData(String pWsdl, String pSessionLogin, String pSearchSpec, int pFetchSize) {
        wsdlURL = pWsdl;
        sessionLogin = pSessionLogin;
        searchSpec = pSearchSpec;
        fetchSize = pFetchSize;
        getNextResultSet(0);
    }

    public void getNextResultSet(int position) {
        setResultIndex(position);

        // Get the query results.
        fetchData(position);
    }

    private void fetchData(int position) {
        String methodName = "fetchData(int)";
        logger.logp(Level.INFO, className, methodName, position + "");
        mData.clear();
        wsTotalRecordCount = 0;
        int recordsToFetchCount = getFetchSize();
        int page = (position < recordsToFetchCount) ? 0 : (position / recordsToFetchCount);
        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(getSessionLogin());
        List<ContactAdministration> usercontactdetails = null;
        String strSearchSpec = null;
        if (getSearchSpec() == null) {
            strSearchSpec =
                    "[Contact.User Flag] = 'Y' AND ([Contact.MFE Contact Role] = 'Primary' OR [Contact.MFE Contact Role] = 'Secondary' OR [Contact.MFE Contact Role] = 'Authorized')";
        } else {
            strSearchSpec = getSearchSpec();
        }
        ArrayOfContactAdministration usercontactdetails1 =
            new EServiceLiteWSProxy().userContactDetailsWithoutPaging(getWsdlURL(), searchSpec, sessionHeader);

        if (usercontactdetails1 != null && usercontactdetails1.getContactAdministration() != null) {
            logger.logp(Level.FINEST, className, methodName,
                        "Number of users returned -" + usercontactdetails1.getContactAdministration().size());

            if (usercontactdetails == null)
                usercontactdetails = usercontactdetails1.getContactAdministration();
            else
                usercontactdetails.addAll(usercontactdetails1.getContactAdministration());
        }
        if (usercontactdetails != null) {
            wsTotalRecordCount = usercontactdetails.size();
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            for (ContactAdministration userdetail : usercontactdetails) {
                logger.finest("User " + startIndex + " : " + userdetail.getLoginName());
                mData.put(startIndex, userdetail);
                ++startIndex;
            }
        }
        if (mData == null) {
            mData = new HashMap<Integer, ContactAdministration>(1);
            logger.logp(Level.INFO, className, methodName, "ContactAdministration does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }
        logger.exiting(className, methodName);
    }

    public ContactAdministration getNextSRData() {
        ContactAdministration contacts = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri);
        }
        contacts = mData.get(ri);
        setResultIndex(ri + 1);
        return contacts;
    }

    public boolean hasNext() {
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public void setRecordCount(int recordCount) {
        this.recordCount = recordCount;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setResultIndex(int resultIndex) {
        this.resultIndex = resultIndex;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public void setFetchedSize(int fetchedSize) {
        this.fetchedSize = fetchedSize;
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public void setResultSize(int resultSize) {
        this.resultSize = resultSize;
    }

    public int getResultSize() {
        return resultSize;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public void setWsTotalRecordCount(int wsTotalRecordCount) {
        this.wsTotalRecordCount = wsTotalRecordCount;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public void setSessionLogin(String sessionGUID) {
        this.sessionLogin = sessionGUID;
    }

    public String getSessionLogin() {
        return sessionLogin;
    }

    public void setWsdlURL(String wsdlURL) {
        this.wsdlURL = wsdlURL;
    }

    public String getWsdlURL() {
        return wsdlURL;
    }

    public void setSearchSpec(String searchSpec) {
        this.searchSpec = searchSpec;
    }

    public String getSearchSpec() {
        return searchSpec;
    }
}
