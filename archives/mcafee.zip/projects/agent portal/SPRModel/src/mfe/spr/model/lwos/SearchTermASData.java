package mfe.spr.model.lwos;

import java.io.Serializable;


public class SearchTermASData implements Serializable {

    private long rowId;
    private long popularity;
    private String searchTerm;
    private String languageCode;
    private String resultsFlag;
    private String productName;
    private String verison;
    private String role;

    public SearchTermASData() {
        super();
    }


    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public long getRowId() {
        return rowId;
    }

    public void setPopularity(long popularity) {
        this.popularity = popularity;
    }

    public long getPopularity() {
        return popularity;
    }

    public void setSearchTerm(String searchTerm) {
        this.searchTerm = searchTerm;
    }

    public String getSearchTerm() {
        return searchTerm;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setResultsFlag(String resultsFlag) {
        this.resultsFlag = resultsFlag;
    }

    public String getResultsFlag() {
        return resultsFlag;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;
    }

    public void setVerison(String verison) {
        this.verison = verison;
    }

    public String getVerison() {
        return verison;
    }


    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof SearchTermASData)) {
            return false;
        }
        final SearchTermASData other = (SearchTermASData)object;
        if (!(searchTerm == null ? other.searchTerm == null : searchTerm.equals(other.searchTerm))) {
            return false;
        }
        if (!(productName == null ? other.productName == null : productName.equals(other.productName))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int PRIME = 37;
        int result = 1;
        result = PRIME * result + ((searchTerm == null) ? 0 : searchTerm.hashCode());
        result = PRIME * result + ((productName == null) ? 0 : productName.hashCode());
        return result;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getRole() {
        return role;
    }
}
