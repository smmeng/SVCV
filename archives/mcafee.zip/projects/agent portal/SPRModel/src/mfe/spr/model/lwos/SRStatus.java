package mfe.spr.model.lwos;

import java.io.Serializable;

public class SRStatus implements Serializable {
    @SuppressWarnings("compatibility:-2076930581094074485")
    private static final long serialVersionUID = -380288177483203440L;
    private String id;
    private String name;
    private String value;

    public SRStatus(com.mcafee.eservicelitews.srstatus.SRStatus wsStatus) {
        super();
        id = wsStatus.getId();
        name = wsStatus.getName();
        value = wsStatus.getValue();
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
