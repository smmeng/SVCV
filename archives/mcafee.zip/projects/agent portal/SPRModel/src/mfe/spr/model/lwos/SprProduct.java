package mfe.spr.model.lwos;

import java.io.Serializable;

import java.util.HashSet;
import java.util.Set;


public class SprProduct implements Serializable {
    @SuppressWarnings("compatibility:-5639476575233897668")
    private static final long serialVersionUID = 6216332360416899581L;

    private String productRowid;
    private String productCode;
    private String productDescription;
    private String active;
    private String MfeChatQueue;
    private String versionFlg;
    private String status;
    private String prodDisplayName;
    private Set<String> versions;

    public SprProduct() {
        super();
    }

    public SprProduct(String productRowid, String productCode, String productDescription, String active,
                      String MfeChatQueue, String versionFlg, String status) {
        this.productRowid = productRowid;
        this.productCode = productCode;
        this.productDescription = productDescription;
        this.active = active;
        this.MfeChatQueue = MfeChatQueue;
        this.versionFlg = versionFlg;
        this.status = status;
    }

    public String getProductRowid() {
        return productRowid;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public String getActive() {
        return active;
    }

    public String getMfeChatQueue() {
        return MfeChatQueue;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof SprProduct)) {
            return false;
        }
        final SprProduct other = (SprProduct)object;
        if (!(productRowid == null ? other.productRowid == null : productRowid.equals(other.productRowid))) {
            return false;
        }
        if (!(productCode == null ? other.productCode == null : productCode.equals(other.productCode))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int PRIME = 37;
        int result = 1;
        result = PRIME * result + ((productRowid == null) ? 0 : productRowid.hashCode());
        result = PRIME * result + ((productCode == null) ? 0 : productCode.hashCode());
        return result;
    }

    public void setVersionFlg(String versionFlg) {
        this.versionFlg = versionFlg;
    }

    public String getVersionFlg() {
        return versionFlg;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setProdDisplayName(String prodDisplayName) {
        this.prodDisplayName = prodDisplayName;
    }

    public String getProdDisplayName() {
        return prodDisplayName;
    }

    public void setVersions(Set<String> versions) {
        this.versions = versions;
    }

    public Set<String> getVersions() {
        if (versions == null) {
            versions = new HashSet<String>();
        }
        return versions;
    }
}
