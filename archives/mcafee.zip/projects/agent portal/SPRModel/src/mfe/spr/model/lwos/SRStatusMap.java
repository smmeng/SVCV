package mfe.spr.model.lwos;

import java.io.Serializable;

public class SRStatusMap implements Serializable {
    @SuppressWarnings("compatibility:8321049673530434195")
    private static final long serialVersionUID = -1852015070752321620L;
    private String statusKey;
    private String displayStatus;

    public SRStatusMap(String key, String value) {
        super();
        statusKey = key;
        displayStatus = value;
    }

    public String getStatusKey() {
        return statusKey;
    }

    public String getDisplayStatus() {
        return displayStatus;
    }
}
