package mfe.spr.model.lwos;

import java.io.Serializable;

import java.math.BigInteger;

import java.sql.Date;


public class DownloadPatchData implements Serializable {

    private BigInteger patchRowId = null;
    private String patchName = null;
    private String patchVersionId = null;
    private String description = null;
    private String status = null;
    private String patchLocation = null;
    private String releaseDateString = null;
    private String patchType = null;
    private String patchSize = null;
    private String patchLanguage = null;
    private String releaseNote = null;
    private String emailNotification = null;
    private String expirationDateString = null;
    private String createdBy = null;
    private Date createdDate = null;
    private String updatedBy = null;
    private Date updatedDate = null;
    private String productVersion = null;
    private String productId = null;
    private String deletedFlag = null;
    private String versionId = null;
    private String patchAccess=null;


    public DownloadPatchData() {
        super();
        patchAccess="Public";
    }


    public void setPatchRowId(BigInteger patchRowId) {
        this.patchRowId = patchRowId;
    }

    public BigInteger getPatchRowId() {
        return patchRowId;
    }

    public void setPatchName(String patchName) {
        this.patchName = patchName;
    }

    public String getPatchName() {
        return patchName;
    }

    public void setPatchVersionId(String patchVersionId) {
        this.patchVersionId = patchVersionId;
    }

    public String getPatchVersionId() {
        return patchVersionId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setPatchLocation(String patchLocation) {
        this.patchLocation = patchLocation;
    }

    public String getPatchLocation() {
        return patchLocation;
    }


    public void setPatchType(String patchType) {
        this.patchType = patchType;
    }

    public String getPatchType() {
        return patchType;
    }

    public void setPatchSize(String patchSize) {
        this.patchSize = patchSize;
    }

    public String getPatchSize() {
        return patchSize;
    }

    public void setPatchLanguage(String patchLanguage) {
        this.patchLanguage = patchLanguage;
    }

    public String getPatchLanguage() {
        return patchLanguage;
    }

    public void setReleaseNote(String releaseNote) {
        this.releaseNote = releaseNote;
    }

    public String getReleaseNote() {
        return releaseNote;
    }

    public void setEmailNotification(String emailNotification) {
        this.emailNotification = emailNotification;
    }

    public String getEmailNotification() {
        return emailNotification;
    }


    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }


    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    public String getProductVersion() {
        return productVersion;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductId() {
        return productId;
    }

    public void setDeletedFlag(String deletedFlag) {
        this.deletedFlag = deletedFlag;
    }

    public String getDeletedFlag() {
        return deletedFlag;
    }

    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    public String getVersionId() {
        return versionId;
    }

    public void setReleaseDateString(String releaseDateString) {
        this.releaseDateString = releaseDateString;
    }

    public String getReleaseDateString() {
        return releaseDateString;
    }


    public void setExpirationDateString(String expirationDateString) {
        this.expirationDateString = expirationDateString;
    }

    public String getExpirationDateString() {
        return expirationDateString;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }


    public void setPatchAccess(String patchAccess) {
        this.patchAccess = patchAccess;
    }

    public String getPatchAccess() {
        return patchAccess;
    }
}
