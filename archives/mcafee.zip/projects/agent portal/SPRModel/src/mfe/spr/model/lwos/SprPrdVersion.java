package mfe.spr.model.lwos;

import java.io.Serializable;

import java.sql.Timestamp;


public class SprPrdVersion implements Serializable {
    @SuppressWarnings("compatibility:-5639476575233897668")
    private static final long serialVersionUID = 6216332360416899581L;

    private String productRowid;
    private String versionId;
    private String productVersion;
    private Timestamp eol;
    private String status;
    private String seblProductNm;


    public SprPrdVersion() {
        super();
    }

    public SprPrdVersion(String productRowid, String versionId, String productVersion, Timestamp eol, String status,
                         String seblProductNm) {
        this.productRowid = productRowid;
        this.productVersion = productVersion;
        this.eol = eol;
        this.status = status;
        this.versionId = versionId;
        this.seblProductNm = seblProductNm;
    }

    public String getProductRowid() {
        return productRowid;
    }

    public void setProductRowid(String productRowid) {
        this.productRowid = productRowid;
    }

    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    public String getProductVersion() {
        return productVersion;
    }

    public void setEol(Timestamp eol) {
        this.eol = eol;
    }

    public Timestamp getEol() {
        return eol;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof SprPrdVersion)) {
            return false;
        }
        final SprPrdVersion other = (SprPrdVersion)object;
        if (!(productRowid == null ? other.productRowid == null : productRowid.equals(other.productRowid))) {
            return false;
        }
        if (!(productVersion == null ? other.productVersion == null : productVersion.equals(other.productVersion))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int PRIME = 37;
        int result = 1;
        result = PRIME * result + ((productRowid == null) ? 0 : productRowid.hashCode());
        result = PRIME * result + ((productVersion == null) ? 0 : productVersion.hashCode());
        return result;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    public String getVersionId() {
        return versionId;
    }

    public void setSeblProductNm(String seblProductNm) {
        this.seblProductNm = seblProductNm;
    }

    public String getSeblProductNm() {
        return seblProductNm;
    }
}
