package mfe.spr.model.lwos;

import java.io.Serializable;

import java.util.Date;


public class InquiraProdSubData implements Serializable {

    private static final long serialVersionUID = 1L;

    public InquiraProdSubData() {
        super();
    }

    protected String rowId;
    protected String product;
    protected String userId;
    protected String localeCode;
    protected String localeDesc;
    protected String contentTypeKey;
    protected String contentType;
    protected Date dateAdded;
    protected String linkURL;


    public InquiraProdSubData(String rowId, String product, String userId, String localeCode, String localeDesc,
                              String contentTypeKey, Date dateAdded) {
        super();
        this.rowId = rowId;
        this.product = product;
        this.userId = userId;
        this.localeCode = localeCode;
        this.localeDesc = localeDesc;
        this.contentTypeKey = contentTypeKey;
        this.dateAdded = dateAdded;
    }

    public void setRowId(String rowId) {
        this.rowId = rowId;
    }

    public String getRowId() {
        return rowId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setLocaleCode(String localeCode) {
        this.localeCode = localeCode;
    }

    public String getLocaleCode() {
        if (localeCode == null) {
            localeCode = "en_US";
        }
        return localeCode;
    }

    public void setLocaleDesc(String localeDesc) {
        this.localeDesc = localeDesc;
    }

    public String getLocaleDesc() {
        return localeDesc;
    }

    public void setContentTypeKey(String contentTypeKey) {
        this.contentTypeKey = contentTypeKey;
    }

    public String getContentTypeKey() {
        return contentTypeKey;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getContentType() {
        return contentType;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public void setLinkURL(String linkURL) {
        this.linkURL = linkURL;
    }

    public String getLinkURL() {
        return linkURL;
    }


    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof InquiraProdSubData)) {
            return false;
        }
        final InquiraProdSubData other = (InquiraProdSubData)object;
        if (!(rowId == null ? other.rowId == null : rowId.equals(other.rowId))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int PRIME = 37;
        int result = 1;
        result = PRIME * result + ((rowId == null) ? 0 : rowId.hashCode());
        return result;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProduct() {
        return product;
    }
}
