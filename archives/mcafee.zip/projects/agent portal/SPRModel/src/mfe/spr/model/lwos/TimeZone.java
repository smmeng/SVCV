package mfe.spr.model.lwos;

import java.io.Serializable;


public class TimeZone implements Serializable {

    protected String active;
    protected String dstAbbreviation;
    protected String name;
    protected String nameTranslation;
    protected String standardAbbreviation;

    public TimeZone() {
        super();
    }


    public void setActive(String active) {
        this.active = active;
    }

    public String getActive() {
        return active;
    }

    public void setDstAbbreviation(String dstAbbreviation) {
        this.dstAbbreviation = dstAbbreviation;
    }

    public String getDstAbbreviation() {
        return dstAbbreviation;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setNameTranslation(String nameTranslation) {
        this.nameTranslation = nameTranslation;
    }

    public String getNameTranslation() {
        return nameTranslation;
    }

    public void setStandardAbbreviation(String standardAbbreviation) {
        this.standardAbbreviation = standardAbbreviation;
    }

    public String getStandardAbbreviation() {
        return standardAbbreviation;
    }
}
