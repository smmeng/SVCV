package mfe.spr.model.lwos;

import java.io.Serializable;

public class SRSubStatus implements Serializable, Comparable {
    @SuppressWarnings("compatibility:-801454304060721168")
    private static final long serialVersionUID = 2613653083349738057L;
    private String id;
    private String parentId;
    private String name;
    private String value;

    public SRSubStatus(com.mcafee.eservicelitews.srsubstatus.SRSubStatus wsSubStatus) {
        super();
        id = wsSubStatus.getId();
        parentId = wsSubStatus.getParentId();
        name = wsSubStatus.getName();
        value = wsSubStatus.getValue();
    }

    public SRSubStatus(String pId, String pParentId, String pName, String pValue) {
        super();
        id = pId;
        parentId = pParentId;
        name = pName;
        value = pValue;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public int compareTo(Object o) {
        if (o != null) {
            SRSubStatus temp = (SRSubStatus)o;
            return this.value.compareToIgnoreCase(temp.getValue());
        }
        return 0;
    }
}
