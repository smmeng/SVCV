package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfAccountAttachment;
import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.platinumportalws.accountattachment.AccountAttachment;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;


public class ManageEnvDocs {

    private static final String className = ManageEnvDocs.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(ManageEnvDocs.class);
    private Map<Integer, AccountAttachment> mData = new LinkedHashMap<Integer, AccountAttachment>();
    private int fetchedSize;
    private int wsTotalRecordCount;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private String sessionLogin;
    private int fetchSize;
    private String wsdlURL;
    private int rangeStartIndex;
    private String AccountId;

    public ManageEnvDocs(String pWsdl, String pSessionGUID, int pFetchSize, String pAccId) {
        wsdlURL = pWsdl;
        sessionLogin = pSessionGUID;
        fetchSize = pFetchSize;
        AccountId = pAccId;
        getNextResultSet(0);
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public int getResultSize() {
        return resultSize;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public String getSessionLogin() {
        return sessionLogin;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public String getWsdlURL() {
        return wsdlURL;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public String getAccountId() {
        return AccountId;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public void setFetchedSize(int fetchedSize) {
        this.fetchedSize = fetchedSize;
    }

    public void setRecordCount(int recordCount) {
        this.recordCount = recordCount;
    }

    public void setResultIndex(int resultIndex) {
        this.resultIndex = resultIndex;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public void getNextResultSet(int position) {
        setResultIndex(position);

        // Get the query results.
        fetchData(position);
    }

    public AccountAttachment getNextSRData() {
        AccountAttachment swDoc = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri);
        }
        swDoc = mData.get(ri);
        setResultIndex(ri + 1);

        return swDoc;
    }


    private void fetchData(int position) {
        String methodName = "fetchData(int)";
        logger.logp(Level.INFO, className, methodName, position + "");
        mData.clear();
        wsTotalRecordCount = 0;
        int recordsToFetchCount = getFetchSize();
        int page = (position < recordsToFetchCount) ? 0 : (position / recordsToFetchCount);
        String searchSpec = "[Account Attachment.Account Id] = '" + this.getAccountId() + "'";
        String sortSpec = "AccntFileName (ASC)";
        String strViewMode = "All";
        String strStartRowNum = "0";
        String pagesize = "50";
        String newquery = "true";
        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(getSessionLogin());
        List<AccountAttachment> accAttachsList = null;

        ArrayOfAccountAttachment arrayofAccdocList =
            new EServiceLiteWSProxy().getPlatinumAttachment(wsdlURL, newquery, pagesize, searchSpec, sortSpec,
                                                            strViewMode, strStartRowNum, sessionHeader);
        if (arrayofAccdocList != null && arrayofAccdocList.getAccountAttachment() != null) {
            if (accAttachsList == null) {
                accAttachsList = arrayofAccdocList.getAccountAttachment();
            } else {
                accAttachsList.addAll(arrayofAccdocList.getAccountAttachment());
            }
        }


        if (accAttachsList != null) {
            wsTotalRecordCount = accAttachsList.size();
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            for (AccountAttachment attDoc : accAttachsList) {
                mData.put(startIndex, attDoc);
                ++startIndex;
            }
        }

        if (mData == null) {
            mData = new HashMap<Integer, AccountAttachment>(1);
            logger.logp(Level.INFO, className, methodName, "Attachments does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }
        logger.exiting(className, methodName);

    }

    public void setResultSize(int resultSize) {
        this.resultSize = resultSize;
    }

    public boolean hasNext() {
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }
}
