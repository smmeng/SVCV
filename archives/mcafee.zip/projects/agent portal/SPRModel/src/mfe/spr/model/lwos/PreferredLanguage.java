package mfe.spr.model.lwos;

import java.io.Serializable;

public class PreferredLanguage implements Serializable {
    @SuppressWarnings("compatibility:-7535361539508392697")
    private static final long serialVersionUID = 871676149878422676L;
    private String languageCode;
    private String languageName;

    public PreferredLanguage(String langCode, String langName) {
        super();
        languageCode = langCode;
        languageName = langName;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String value) {
        this.languageCode = value;
    }

    public String getLanguageName() {
        return languageName;
    }

    public void setLanguageName(String value) {
        this.languageName = value;
    }

}
