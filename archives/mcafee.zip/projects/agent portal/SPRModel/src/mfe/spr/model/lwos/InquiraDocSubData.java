package mfe.spr.model.lwos;

import java.io.Serializable;

import java.util.Date;


public class InquiraDocSubData implements Serializable {


    @SuppressWarnings("compatibility:1744069641082588471")
    private static final long serialVersionUID = 1L;

    public InquiraDocSubData() {
        super();
    }

    protected String userId;
    protected String documentId;
    protected String title;
    protected String contentTypeKey;
    protected String contentType;
    protected Date dateAdded;
    protected Date dateLastModified;
    protected String localeCode;
    protected String localeDesc;
    protected String channelId;
    protected String rowId;
    protected String linkURL;

    public InquiraDocSubData(String userId, String documentId, String title, String contentTypeKey, Date dateAdded,
                             Date dateLastModified, String localeCode, String localeDesc, String channelId,
                             String rowId) {
        super();
        this.userId = userId;
        this.documentId = documentId;
        this.title = title;
        this.contentTypeKey = contentTypeKey;
        this.dateAdded = dateAdded;
        this.dateLastModified = dateLastModified;
        this.localeCode = localeCode;
        this.localeDesc = localeDesc;
        this.channelId = channelId;
        this.rowId = rowId;
    }


    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getContentType() {
        return contentType;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    public Date getDateAdded() {
        return dateAdded;
    }


    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof InquiraDocSubData)) {
            return false;
        }
        final InquiraDocSubData other = (InquiraDocSubData)object;
        if (!(rowId == null ? other.rowId == null : rowId.equals(other.rowId))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int PRIME = 37;
        int result = 1;
        result = PRIME * result + ((rowId == null) ? 0 : rowId.hashCode());
        return result;
    }

    public void setLinkURL(String linkURL) {
        this.linkURL = linkURL;
    }

    public String getLinkURL() {
        return linkURL;
    }

    public void setContentTypeKey(String contentTypeKey) {
        this.contentTypeKey = contentTypeKey;
    }

    public String getContentTypeKey() {
        return contentTypeKey;
    }

    public void setDateLastModified(Date dateLastModified) {
        this.dateLastModified = dateLastModified;
    }

    public Date getDateLastModified() {
        return dateLastModified;
    }

    public void setLocaleCode(String localeCode) {
        this.localeCode = localeCode;
    }

    public String getLocaleCode() {
        if (localeCode == null) {
            localeCode = "en_US";
        }
        return localeCode;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setRowId(String rowId) {
        this.rowId = rowId;
    }

    public String getRowId() {
        return rowId;
    }

    public void setLocaleDesc(String localeDesc) {
        this.localeDesc = localeDesc;
    }

    public String getLocaleDesc() {
        return localeDesc;
    }
}
