package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfSWDownloadsList;
import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.eservicelitews.swdownloadslist.SWDownloadsList;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;


public class DownloadData {
    private static final String className = DownloadData.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(DownloadData.class);

    private Map<Integer, SWDownloadsList> mData = new LinkedHashMap<Integer, SWDownloadsList>();
    private int wsTotalRecordCount;
    private int fetchedSize;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private String sessionLogin;
    private int fetchSize;
    private String wsdlURL;
    private int rangeStartIndex;
    private String[] siebelAccountIds;

    public DownloadData(String pWsdl, String pSessionLogin, int pFetchSize) {
        wsdlURL = pWsdl;
        sessionLogin = pSessionLogin;
        fetchSize = pFetchSize;
        getNextResultSet(0);
    }

    public String getSessionLogin() {
        return sessionLogin;
    }

    public String getWsdlURL() {
        return wsdlURL;
    }

    public void setFetchedSize(int size) {
        fetchedSize = size;
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(int count) {
        recordCount = count;
    }

    public void setResultSize(int size) {
        resultSize = size;
    }

    public int getResultSize() {
        return resultSize;
    }

    public void setResultIndex(int index) {
        resultIndex = index;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public void getNextResultSet(int position) {
        setResultIndex(position);

        // Get the query results.
        fetchData(position);
    }

    public boolean hasNext() {
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public SWDownloadsList getNextSRData() {
        SWDownloadsList swDownload = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri);
        }
        swDownload = mData.get(ri);
        setResultIndex(ri + 1);

        return swDownload;
    }

    private void fetchData(int position) {
        String methodName = "fetchData(int)";
        logger.entering(className, methodName, position);
        mData.clear();
        wsTotalRecordCount = 0;

        int recordsToFetchCount = getFetchSize();
        int page = (position < recordsToFetchCount) ? 0 : (position / recordsToFetchCount);

        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(getSessionLogin());

        List<SWDownloadsList> softwareList = null;
        boolean getMore = true;
        int i = 0;
        while (getMore) {
            ArrayOfSWDownloadsList swList =
                new EServiceLiteWSProxy().swDownloadList(getWsdlURL(), "", "Name(ASC)", 100, i, sessionHeader);
            if (swList != null && swList.getSWDownloadsList() != null) {
                if (swList.getSWDownloadsList().size() < 100) {
                    getMore = false;
                }
                if (softwareList == null) {
                    softwareList = swList.getSWDownloadsList();
                } else {
                    softwareList.addAll(swList.getSWDownloadsList());
                }
                i++;
            } else {
                getMore = false;
                break;
            }
        }

        if (softwareList != null) {
            wsTotalRecordCount = softwareList.size();
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            for (SWDownloadsList swDownload : softwareList) {
                mData.put(startIndex, swDownload);
                ++startIndex;
            }
        }

        if (mData == null) {
            mData = new HashMap<Integer, SWDownloadsList>(1);
            logger.logp(Level.INFO, className, methodName, "Download Info does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }
        logger.exiting(className, methodName);
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public String[] getSiebelAccountIds() {
        return siebelAccountIds;
    }
}
