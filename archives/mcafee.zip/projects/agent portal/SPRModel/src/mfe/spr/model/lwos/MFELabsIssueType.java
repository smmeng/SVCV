package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.mcafeelabsissuetype.McAfeeLabsIssueType;

import java.io.Serializable;


public class MFELabsIssueType implements Serializable {
    @SuppressWarnings("compatibility:-5911691279973235365")
    private static final long serialVersionUID = -4899973541400159167L;
    private String id;
    private String parentId;
    private String productName;
    private String issueType;

    public MFELabsIssueType(McAfeeLabsIssueType pWSLOV) {
        super();
        id = pWSLOV.getId();
        parentId = pWSLOV.getParentId();
        productName = pWSLOV.getProductName();
        issueType = pWSLOV.getIssueType();
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public String getIssueType() {
        return issueType;
    }
}
