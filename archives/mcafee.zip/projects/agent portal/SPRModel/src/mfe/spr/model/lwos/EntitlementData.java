package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfAnEInfo;
import com.mcafee.eservicelitews.ArrayOfString;
import com.mcafee.eservicelitews.aneinfo.AnEInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.xml.ws.Holder;

import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.SortCriteria;

import org.apache.commons.lang.StringUtils;


public class EntitlementData {
    private static final String className = EntitlementData.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(EntitlementData.class);
    private static final String STATUS_ACTIVE = "Active";

    private static Map<String, String> sortSpecNameMapping = new HashMap<String, String>(5);
    static {
        sortSpecNameMapping.put("GrantNumber", "[Grant Number]");
        sortSpecNameMapping.put("Type", "[Type]");
        sortSpecNameMapping.put("Status", "[Status]");
        sortSpecNameMapping.put("NumberOfNodesLicensed", "[Number of Node licensed]");
        sortSpecNameMapping.put("SKU", "[SKU]");
        sortSpecNameMapping.put("SupportLevel", "[Support Level]");
        sortSpecNameMapping.put("SerialNumber", "[Serial Number]");
        sortSpecNameMapping.put("StartDate", "[Start Date]");
        sortSpecNameMapping.put("EndDate", "[End Date]");
    }

    private Map<Integer, AnEInfo> mData = new LinkedHashMap<Integer, AnEInfo>();
    private int wsTotalRecordCount;
    private int fetchedSize;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private SortCriteria[] sortCriteria;
    private int fetchSize;
    private String wsdlURL;
    private int rangeStartIndex;
    private String[] siebelAccountIds;

    /* added on 15 may - sambha */
    String loginUserName;
    String statusFilter;
    String supportLevelFilter;
    String hardwareSerialNumberFilter;
    String sortspec = "";
    Boolean isFilterValuesRequired;
    Holder<ArrayOfAnEInfo> anEInfo = new Holder<ArrayOfAnEInfo>();
    Holder<Integer> totalRecordCount = new Holder<Integer>();

    Holder<ArrayOfString> listOfStatus = new Holder<ArrayOfString>();
    Holder<ArrayOfString> listOfSupportLevel = new Holder<ArrayOfString>();
    Holder<ArrayOfString> listOfHardwarSerialNumber = new Holder<ArrayOfString>();
    String sortedBy;
    String orderedBy;

    public EntitlementData(String pWsdl, int pFetchSize, Boolean pIsFilterValuesRequired, String pLoginUserName,
                           String pStatusFilter, String pSupportLevelFilter, String pHardwareSerialNumberFilter,
                           String pSortedBy, String pOrderedBy) {
        wsdlURL = pWsdl;
        statusFilter = pStatusFilter;
        supportLevelFilter = pSupportLevelFilter;
        hardwareSerialNumberFilter = pHardwareSerialNumberFilter;
        loginUserName = pLoginUserName;
        isFilterValuesRequired = pIsFilterValuesRequired;
        fetchSize = pFetchSize;
        sortedBy = pSortedBy;
        orderedBy = pOrderedBy;

        getNextResultSet(0);
    }

    private String getSortSpecName() {
        if (StringUtils.isNotEmpty(sortedBy)) {
            return sortSpecNameMapping.get(sortedBy);
        } else {
            return sortSpecNameMapping.get("EndDate");
        }
    }

    private String getSortOrder() {
        if (StringUtils.isNotEmpty(orderedBy)) {
            return orderedBy;
        } else {
            return "DESC";
        }
    }

    private String getWSSortSpec() {
        return getSortSpecName() + " " + getSortOrder();
    }

    public String getWsdlURL() {
        return wsdlURL;
    }

    public void setFetchedSize(int size) {
        fetchedSize = size;
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(int count) {
        recordCount = count;
    }

    public void setResultSize(int size) {
        resultSize = size;
    }

    public int getResultSize() {
        return resultSize;
    }

    public void setResultIndex(int index) {
        resultIndex = index;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public void getNextResultSet(int position) {
        setResultIndex(position);

        // Get the query results.
        fetchData(position);
    }

    public boolean hasNext() {
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public AnEInfo getNextSRData() {
        AnEInfo entInfo = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri);
        }
        entInfo = mData.get(ri);
        setResultIndex(ri + 1);

        return entInfo;
    }

    public List<String> getlistOfStatus() {
        if (listOfStatus == null || listOfStatus.value == null || null == listOfStatus.value.getString()) {
            List<String> statuslist = new ArrayList<String>();
            statuslist.add(STATUS_ACTIVE);
            return statuslist;
        } else if (!listOfStatus.value.getString().contains(STATUS_ACTIVE)) {
            // If Web Service does not return status "Active", will add it
            List<String> statusList = listOfStatus.value.getString();
            statusList.add(0, STATUS_ACTIVE);
            return statusList;
        } else {
            return listOfStatus.value.getString();
        }
    }

    public List<String> getlistOfSupportLevel() {
        List<String> supportLevellist;
        if (null == listOfSupportLevel.value) {
            supportLevellist = new ArrayList<String>();
            supportLevellist.add("All");
            return supportLevellist;

        } else {
            supportLevellist = listOfSupportLevel.value.getString();
            supportLevellist.add(0, "All");
            return supportLevellist;
        }
    }

    public List<String> getlistOfHardwarSerialNumber() {
        List<String> hardwarSerialNumberlist;
        if (null == listOfHardwarSerialNumber.value) {
            hardwarSerialNumberlist = new ArrayList<String>();
            hardwarSerialNumberlist.add("All");
            return hardwarSerialNumberlist;
        } else {
            hardwarSerialNumberlist = listOfHardwarSerialNumber.value.getString();
            hardwarSerialNumberlist.add(0, "All");
            return hardwarSerialNumberlist;
        }
    }

    private void fetchData(int position) {
        String methodName = "fetchData(int)";
        logger.entering(className, methodName, position);
        mData.clear();
        wsTotalRecordCount = 0;

        int recordsToFetchCount = getFetchSize();
        int page = (position < recordsToFetchCount) ? 0 : (position / recordsToFetchCount);

        new EServiceLiteWSProxy().getAEListByLoginName(wsdlURL, loginUserName, statusFilter, supportLevelFilter,
                                                       hardwareSerialNumberFilter, getWSSortSpec(),
                                                       isFilterValuesRequired, page, recordsToFetchCount, anEInfo,
                                                       totalRecordCount, listOfStatus, listOfSupportLevel,
                                                       listOfHardwarSerialNumber);
        List<AnEInfo> arrayOfEntitlements;

        if (null == anEInfo.value) {
            arrayOfEntitlements = new ArrayList<AnEInfo>();

        } else {
            arrayOfEntitlements = anEInfo.value.getAnEInfo();
        }

        if (arrayOfEntitlements != null && arrayOfEntitlements.size() != 0) {
            wsTotalRecordCount = totalRecordCount.value;
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            for (AnEInfo anEInfo : arrayOfEntitlements) {
                mData.put(startIndex, anEInfo);
                ++startIndex;
            }
        }

        if (mData == null) {
            mData = new HashMap<Integer, AnEInfo>(1);
            logger.logp(Level.INFO, className, methodName, "Entitlement Info does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }
        logger.exiting(className, methodName);
    }

    public void setSortCriteria(SortCriteria[] pSortCriteria) {
        sortCriteria = pSortCriteria;
    }

    public SortCriteria[] getSortCriteria() {
        return sortCriteria;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public String[] getSiebelAccountIds() {
        return siebelAccountIds;
    }
}
