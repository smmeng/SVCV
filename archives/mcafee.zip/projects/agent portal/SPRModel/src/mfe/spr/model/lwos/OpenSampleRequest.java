package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfServiceRequestLite;
import com.mcafee.eservicelitews.ArrayOfSiebelAccount;
import com.mcafee.eservicelitews.ArrayOfSortSpec;
import com.mcafee.eservicelitews.servicerequest.SRFilters;
import com.mcafee.eservicelitews.servicerequest.ServiceRequestLite;
import com.mcafee.eservicelitews.servicerequest.SortSpec;
import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.eservicelitews.siebelaccount.SiebelAccount;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.xml.ws.Holder;

import mfe.spr.model.queries.trans.GeneralInfoTRVORowImpl;
import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.domain.Array;


public class OpenSampleRequest {
    private static final String className = OpenSampleRequest.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(OpenSampleRequest.class);

    private Map<Integer, ServiceRequestLite> mData = new HashMap<Integer, ServiceRequestLite>();
    private int wsTotalRecordCount;
    private int fetchedSize;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private SortSpec sortSpec;
    private SRFilters searchSpec;
    private int fetchSize;
    private int rangeStartIndex;
    private String wsWSDLUrl;

    public OpenSampleRequest(int pFetchSize, String wsdlUrl, GeneralInfoTRVORowImpl generalInfoTRVORow) {
        setWsWSDLUrl(wsdlUrl);
        setFetchSize(pFetchSize);
        getNextResultSet(0, generalInfoTRVORow);
    }

    public void setFetchedSize(int size) {
        fetchedSize = size;
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(int count) {
        recordCount = count;
    }

    public void setResultSize(int size) {
        resultSize = size;
    }

    public int getResultSize() {
        return resultSize;
    }

    public void setResultIndex(int index) {
        resultIndex = index;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public void getNextResultSet(int position, GeneralInfoTRVORowImpl generalInfoTRVORow) {
        setResultIndex(position);
        //    setSortCriteria();
        // Get the query results.
        fetchData(position, generalInfoTRVORow);
    }

    public boolean hasNext() {
        //if ((fetchedSize - resultSize + resultIndex) < recordCount)
        //if (resultIndex < (rangeStartIndex + resultSize))
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public ServiceRequestLite getNextSRData(GeneralInfoTRVORowImpl generalInfoTRVORow) {
        ServiceRequestLite sr = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri, generalInfoTRVORow);
        }
        sr = mData.get(ri);
        setResultIndex(ri + 1);
        return sr;
    }

    private void fetchData(int position, GeneralInfoTRVORowImpl generalInfoTRVORow) {
        String methodName = "fetchData(int)";

        int recordsToFetchCount = getFetchSize();
        int page = (position <= recordsToFetchCount) ? 0 : (position / recordsToFetchCount);

        SRFilters srFilters = new SRFilters();
        srFilters.setSRType(6);
        srFilters.setStatus("Open");

        ArrayOfSortSpec sortSpec = new ArrayOfSortSpec();
        SortSpec spec = new SortSpec();
        spec.setName("sRNumberField");
        spec.setSortOrder("DESC");
        spec.setSortSequence("1");
        sortSpec.getSortSpec().add(spec);

        Holder<Integer> totalRecordCount = new Holder<Integer>();
        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(generalInfoTRVORow.getLoginName());
        Holder<ArrayOfServiceRequestLite> arrayOfSRLite = new Holder<ArrayOfServiceRequestLite>();

        // Fetch data
        getMyServiceRequest(srFilters, generalInfoTRVORow, recordsToFetchCount, page, sortSpec, arrayOfSRLite,
                            totalRecordCount, sessionHeader);

        // update the size variable
        if (totalRecordCount != null && totalRecordCount.value != null) {
            wsTotalRecordCount = totalRecordCount.value.intValue();
            if (totalRecordCount.value > recordsToFetchCount) {
                setRecordCount(recordsToFetchCount);
            } else {
                setRecordCount(totalRecordCount.value);
            }
        } else {
            wsTotalRecordCount = 0;
        }

        if (arrayOfSRLite != null && arrayOfSRLite.value != null) {
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            List<ServiceRequestLite> srLiteList = arrayOfSRLite.value.getServiceRequestLite();
            for (ServiceRequestLite srLite : srLiteList) {
                mData.put(startIndex, srLite);
                ++startIndex;
            }
        }
        if (mData == null) {
            mData = new HashMap<Integer, ServiceRequestLite>(1);
            logger.logp(Level.INFO, className, methodName, "Service Request does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }
    }

    private void getMyServiceRequest(SRFilters srFilters, GeneralInfoTRVORowImpl generalInfoTRVORow, int recordCount,
                                     int page, ArrayOfSortSpec sortSpec,
                                     Holder<ArrayOfServiceRequestLite> arrayOfSRLite, Holder<Integer> totalRecordCount,
                                     SessionHeader sessionHeader) {
        ArrayOfSiebelAccount siebelAccountList_banned = new ArrayOfSiebelAccount();
        java.util.List<SiebelAccount> accountList_banned = siebelAccountList_banned.getSiebelAccount();
        Array array = generalInfoTRVORow.getBannedSiebelAccounts();
        if (array != null) {
            SiebelAccount account = null;
            for (Object obj : array.getArray()) {
                account = new SiebelAccount();
                account.setId((String)obj);
                accountList_banned.add(account);
            }
        }

        new EServiceLiteWSProxy().getPersonalServiceRequests(getWsWSDLUrl(), srFilters, false,
                                                             generalInfoTRVORow.getContactId(),
                                                             siebelAccountList_banned, recordCount, page, sortSpec,
                                                             arrayOfSRLite, totalRecordCount, sessionHeader);
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    /*  public List<ServiceRequestLite> fetchAllRecords()
  {

      SRFilters srFilters = new SRFilters();
      srFilters.setSRType(6);
      srFilters.setStatus("Open");
      //srFilters.setSubStatus(searchSpec.getSubStatus());
      //srFilters.setProduct(searchSpec.getProduct());

      ArrayOfSortSpec sortSpec = new ArrayOfSortSpec();
      SortSpec spec = new SortSpec();
      //spec.setName("");
      spec.setSortOrder("DESC");
      spec.setSortSequence("1");
      sortSpec.getSortSpec().add(spec);

    Holder<Integer> totalRecordCount = new Holder<Integer>();
    SessionHeader sessionHeader = new SessionHeader();
    sessionHeader.setSessionGUID(generalInfoTRVORow.getSessionGUID());
    Holder<ArrayOfServiceRequestLite> arrayOfSRLite = new Holder<ArrayOfServiceRequestLite>();

    EServiceLiteWSSoap service = new EServiceLiteWSProxy().getEServiceLiteWSSOAP(SPRCoherenceCacheUtils.getProperty(SPRConstants.ESERVICE_LITE_WSDL_URL_KEY));

    // Fetch data

    int page = 0, totalCount = 0, fetchCount = 100;
    List<ServiceRequestLite> srList = new ArrayList<ServiceRequestLite>();
    do
    {

    getMyServiceRequest(service, srFilters, generalInfoTRVORow.getContactId(), fetchCount, page, sortSpec, arrayOfSRLite, totalRecordCount, sessionHeader);

      // update the size variable
      if (page == 0 && totalRecordCount != null && totalRecordCount.value != null)
      {
        totalCount = totalRecordCount.value.intValue();
      }

      if(arrayOfSRLite != null && arrayOfSRLite.value != null)
      {
        srList.addAll(arrayOfSRLite.value.getServiceRequestLite());
      }

      if (srList.size() < totalCount)
      {
        if ((totalCount - srList.size()) < fetchSize)
        {
          fetchCount = totalCount - srList.size();
        }
        ++page;
      }
      else
      {
        page = -1;
      }
    } while (page != -1);

      return srList;
  } */

    public void setSortSpec(SortSpec sortSpec) {
        this.sortSpec = sortSpec;
    }

    public SortSpec getSortSpec() {
        return sortSpec;
    }

    public void setSearchSpec(SRFilters searchSpec) {
        this.searchSpec = searchSpec;
    }

    public SRFilters getSearchSpec() {
        return searchSpec;
    }

    public void setWsWSDLUrl(String wsWSDLUrl) {
        this.wsWSDLUrl = wsWSDLUrl;
    }

    public String getWsWSDLUrl() {
        return wsWSDLUrl;
    }
}
