package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfPlatinumTeam;
import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.platinumportalws.platinumteam.PlatinumTeam;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;


public class TeamData {

    private static final String className = TeamData.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(TeamData.class);

    private Map<Integer, PlatinumTeam> mData = new LinkedHashMap<Integer, PlatinumTeam>();
    private int wsTotalRecordCount;
    private int fetchedSize;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private String sessionLogin;
    private String accountId;
    private int fetchSize;
    private String wsdlURL;
    private int rangeStartIndex;
    private String[] siebelAccountIds;


    public TeamData(String pWsdl, String pSessionLogin, String pAccountId, int pFetchSize) {
        wsdlURL = pWsdl;
        sessionLogin = pSessionLogin;
        fetchSize = pFetchSize;
        accountId = pAccountId;
        getNextResultSet(0);
    }

    public String getSessionLogin() {
        return sessionLogin;
    }

    public String getWsdlURL() {
        return wsdlURL;
    }

    public void setFetchedSize(int size) {
        fetchedSize = size;
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(int count) {
        recordCount = count;
    }

    public void setResultSize(int size) {
        resultSize = size;
    }

    public int getResultSize() {
        return resultSize;
    }

    public void setResultIndex(int index) {
        resultIndex = index;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public void getNextResultSet(int position) {
        setResultIndex(position);
        // Get the query results.
        fetchData(position);
    }

    public boolean hasNext() {
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public PlatinumTeam getNextSRData() {
        PlatinumTeam swDownload = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri);
        }
        swDownload = mData.get(ri);
        setResultIndex(ri + 1);

        return swDownload;
    }

    private void fetchData(int position) {
        String methodName = "fetchData(int)";
        logger.entering(className, methodName, position);
        mData.clear();
        wsTotalRecordCount = 0;
        logger.logp(Level.INFO, className, methodName, position + "fetchData() in TeamData");

        int recordsToFetchCount = getFetchSize();
        int page = (position < recordsToFetchCount) ? 0 : (position / recordsToFetchCount);

        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(getSessionLogin());
        List<PlatinumTeam> teamDetailsList = null;

        int i = 0;
        String searchSpec = "[MFE ServicePortal Team.Account Id] = '" + accountId + "'";

        ArrayOfPlatinumTeam arrayOfTeamList =
            new EServiceLiteWSProxy().queryTeamWithoutPaging(wsdlURL, searchSpec, sessionHeader);
        if (arrayOfTeamList != null && arrayOfTeamList.getPlatinumTeam() != null) {
            if (teamDetailsList == null) {
                teamDetailsList = arrayOfTeamList.getPlatinumTeam();
            } else {
                teamDetailsList.addAll(arrayOfTeamList.getPlatinumTeam());
            }

        } else {
            logger.logp(Level.INFO, className, methodName,
                        "arrayOfTeamList from queryTeamWithoutPaging in TeamData is empty");

        }

        if (teamDetailsList != null) {
            wsTotalRecordCount = teamDetailsList.size();
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            for (PlatinumTeam role : teamDetailsList) {
                mData.put(startIndex, role);
                ++startIndex;
            }
            logger.logp(Level.INFO, className, methodName, "Number of Teams" + teamDetailsList.size());
        } else {
            logger.logp(Level.INFO, className, methodName, "teamDetailsList in TeamData is empty");

        }

        if (mData == null) {
            mData = new HashMap<Integer, PlatinumTeam>(1);
            logger.logp(Level.INFO, className, methodName, "Team Info does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }
        logger.exiting(className, methodName);
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public String[] getSiebelAccountIds() {
        return siebelAccountIds;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountId() {
        return accountId;
    }
}
