package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfContactAdministration;
import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.platinumportalws.contactadministration.ContactAdministration;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;


//import mfe.spr.proxy.elite.EServiceLiteWSProxy;


//import oracle.jbo.SortCriteria;

public class TeamUsersData {
    private static final String className = TeamUsersData.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(TeamUsersData.class);
    private Map<Integer, ContactAdministration> mData = new LinkedHashMap<Integer, ContactAdministration>();
    private int fetchedSize;
    private int wsTotalRecordCount;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private String sessionLogin;
    private int fetchSize;
    private String wsdlURL;
    private int rangeStartIndex;
    private String searchSpec;

    public TeamUsersData(String pWsdl, String pSessionLogin, String mSearchSpec, int pFetchSize) {
        wsdlURL = pWsdl;
        sessionLogin = pSessionLogin;
        fetchSize = pFetchSize;
        searchSpec = mSearchSpec;
        getNextResultSet(0);
    }

    public void getNextResultSet(int position) {
        setResultIndex(position);

        // Get the query results.
        fetchData(position);
    }

    private void fetchData(int position) {
        String methodName = "fetchData(int)";
        logger.logp(Level.INFO, className, methodName, position + "fetchData() in TeamUsersData");
        mData.clear();
        wsTotalRecordCount = 0;
        int recordsToFetchCount = getFetchSize();
        int page = (position < recordsToFetchCount) ? 0 : (position / recordsToFetchCount);
        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(getSessionLogin());
        List<ContactAdministration> usercontactdetails = null;
        ArrayOfContactAdministration usercontactdetails1 =
            new EServiceLiteWSProxy().userContactDetails(wsdlURL, "true", "100", searchSpec, "Last Name (ASC)", "All",
                                                         "0", sessionHeader);
        if (usercontactdetails1 != null && usercontactdetails1.getContactAdministration() != null) {
            if (usercontactdetails == null)
                usercontactdetails = usercontactdetails1.getContactAdministration();
            else
                usercontactdetails.addAll(usercontactdetails1.getContactAdministration());
        } else {
            logger.logp(Level.FINEST, className, methodName,
                        "USERCONTACTDETAILS1 is NULL in fetchData() in TeamUsersData");
        }
        if (usercontactdetails != null) {
            wsTotalRecordCount = usercontactdetails.size();
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            for (ContactAdministration userdetail : usercontactdetails) {
                mData.put(startIndex, userdetail);
                ++startIndex;
            }
            logger.logp(Level.FINEST, className, methodName, "Number of Users in Teams" + usercontactdetails.size());
        } else {
            logger.logp(Level.FINEST, className, methodName,
                        "USERCONTACTDETAILS is NULL in fetchData() in TeamUsersData");
        }
        if (mData == null) {
            mData = new HashMap<Integer, ContactAdministration>(1);
            logger.logp(Level.INFO, className, methodName, "ContactAdministration does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }
        logger.exiting(className, methodName);
    }

    public ContactAdministration getNextSRData() {
        ContactAdministration contacts = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri);
        }
        contacts = mData.get(ri);
        setResultIndex(ri + 1);
        return contacts;
    }

    public boolean hasNext() {
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public void setRecordCount(int recordCount) {
        this.recordCount = recordCount;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setResultIndex(int resultIndex) {
        this.resultIndex = resultIndex;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public void setFetchedSize(int fetchedSize) {
        this.fetchedSize = fetchedSize;
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public void setResultSize(int resultSize) {
        this.resultSize = resultSize;
    }

    public int getResultSize() {
        return resultSize;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public void setWsTotalRecordCount(int wsTotalRecordCount) {
        this.wsTotalRecordCount = wsTotalRecordCount;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public void setSessionLogin(String sessionLogin) {
        this.sessionLogin = sessionLogin;
    }

    public String getSessionLogin() {
        return sessionLogin;
    }

    public void setWsdlURL(String wsdlURL) {
        this.wsdlURL = wsdlURL;
    }

    public String getWsdlURL() {
        return wsdlURL;
    }

    public void setSearchSpec(String searchSpec) {
        this.searchSpec = searchSpec;
    }

    public String getSearchSpec() {
        return searchSpec;
    }
}
