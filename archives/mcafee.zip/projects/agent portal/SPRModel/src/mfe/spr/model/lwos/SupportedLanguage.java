package mfe.spr.model.lwos;

import java.io.Serializable;

public class SupportedLanguage implements Serializable {
    private String languageCode;
    private String languageName;
    private String languageDisplayName;

    public SupportedLanguage() {
        super();
    }


    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof SupportedLanguage)) {
            return false;
        }
        final SupportedLanguage other = (SupportedLanguage)object;
        if (!(languageCode == null ? other.languageCode == null : languageCode.equals(other.languageCode))) {
            return false;
        }
        if (!(languageName == null ? other.languageName == null : languageName.equals(other.languageName))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int PRIME = 37;
        int result = 1;
        result = PRIME * result + ((languageCode == null) ? 0 : languageCode.hashCode());
        result = PRIME * result + ((languageName == null) ? 0 : languageName.hashCode());
        return result;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }

    public String getLanguageName() {
        return languageName;
    }

    public void setLanguageDisplayName(String languageDisplayName) {
        this.languageDisplayName = languageDisplayName;
    }

    public String getLanguageDisplayName() {
        return languageDisplayName;
    }
}
