package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfServiceRequestLite;
import com.mcafee.eservicelitews.ArrayOfSiebelAccount;
import com.mcafee.eservicelitews.ArrayOfSortSpec;
import com.mcafee.eservicelitews.servicerequest.SRFilters;
import com.mcafee.eservicelitews.servicerequest.ServiceRequestLite;
import com.mcafee.eservicelitews.servicerequest.SortSpec;
import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.eservicelitews.siebelaccount.SiebelAccount;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.xml.ws.Holder;

import mfe.spr.model.queries.trans.GeneralInfoTRVORowImpl;
import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.domain.Array;


public class MERSRRequest {
    private static final String className = MERSRRequest.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(MERSRRequest.class);

    private Map<Integer, ServiceRequestLite> mData = new HashMap<Integer, ServiceRequestLite>();
    private int wsTotalRecordCount;
    private int fetchedSize;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private SortSpec sortSpec;
    private SRFilters searchSpec;
    private int fetchSize;
    private int rangeStartIndex;
    private String wsWSDLUrl;

    public MERSRRequest(int pFetchSize, String wsdlUrl, GeneralInfoTRVORowImpl generalInfoTRVORow, boolean isPlatinum,
                        String permission) {
        setWsWSDLUrl(wsdlUrl);
        setFetchSize(pFetchSize);
        getNextResultSet(0, generalInfoTRVORow, isPlatinum, permission);
    }

    public void setFetchedSize(int size) {
        fetchedSize = size;
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(int count) {
        recordCount = count;
    }

    public void setResultSize(int size) {
        resultSize = size;
    }

    public int getResultSize() {
        return resultSize;
    }

    public void setResultIndex(int index) {
        resultIndex = index;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public void getNextResultSet(int position, GeneralInfoTRVORowImpl generalInfoTRVORow, boolean isPlatinum,
                                 String permission) {
        setResultIndex(position);
        //    setSortCriteria();
        // Get the query results.
        fetchData(position, generalInfoTRVORow, isPlatinum, permission);
    }

    public boolean hasNext() {
        //if ((fetchedSize - resultSize + resultIndex) < recordCount)
        //if (resultIndex < (rangeStartIndex + resultSize))
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public ServiceRequestLite getNextSRData(GeneralInfoTRVORowImpl generalInfoTRVORow, boolean isPlatinum,
                                            String permission) {
        ServiceRequestLite sr = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri, generalInfoTRVORow, isPlatinum, permission);
        }
        sr = mData.get(ri);
        setResultIndex(ri + 1);

        return sr;
    }

    private void fetchData(int position, GeneralInfoTRVORowImpl generalInfoTRVORow, boolean isPlatinum,
                           String permission) {
        String methodName = "fetchData(int)";

        int recordsToFetchCount = getFetchSize();
        int page = (position < recordsToFetchCount) ? 0 : (position / recordsToFetchCount);

        SRFilters srFilters = new SRFilters();
        srFilters.setSRType(1);
        srFilters.setStatus("Open");
        srFilters.setProduct("");
        srFilters.setSubStatus("");

        ArrayOfSortSpec sortSpec = new ArrayOfSortSpec();
        SortSpec spec = new SortSpec();
        spec.setName("createdField");
        spec.setSortOrder("DESC");
        spec.setSortSequence("1");
        sortSpec.getSortSpec().add(spec);

        Holder<Integer> totalRecordCount = new Holder<Integer>();
        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(generalInfoTRVORow.getLoginName());
        Holder<ArrayOfServiceRequestLite> arrayOfSRLite = new Holder<ArrayOfServiceRequestLite>();
        if (!isPlatinum || (isPlatinum && "company".equalsIgnoreCase(permission)))
            getAllServiceRequest(getWsWSDLUrl(), srFilters, generalInfoTRVORow, recordsToFetchCount, page, sortSpec,
                                 arrayOfSRLite, totalRecordCount, sessionHeader);
        else if (isPlatinum && "team".equalsIgnoreCase(permission))
            getTeamServiceRequest(getWsWSDLUrl(), srFilters, generalInfoTRVORow, recordsToFetchCount, page, sortSpec,
                                  arrayOfSRLite, totalRecordCount, sessionHeader);
        else if (isPlatinum && "personal".equalsIgnoreCase(permission))
            getMyServiceRequest(getWsWSDLUrl(), srFilters, generalInfoTRVORow, recordsToFetchCount, page, sortSpec,
                                arrayOfSRLite, totalRecordCount, sessionHeader);
        // update the size variable
        if (totalRecordCount != null && totalRecordCount.value != null) {
            wsTotalRecordCount = totalRecordCount.value.intValue();
            if (totalRecordCount.value > recordsToFetchCount) {
                setRecordCount(recordsToFetchCount);
            } else {
                setRecordCount(totalRecordCount.value);
            }
        } else {
            wsTotalRecordCount = 0;
        }

        if (arrayOfSRLite != null && arrayOfSRLite.value != null) {
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            List<ServiceRequestLite> srLiteList = arrayOfSRLite.value.getServiceRequestLite();
            for (ServiceRequestLite srLite : srLiteList) {
                mData.put(startIndex, srLite);
                ++startIndex;
            }
        }

        if (mData == null) {
            mData = new HashMap<Integer, ServiceRequestLite>(1);
            logger.logp(Level.INFO, className, methodName, "Service Request does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }
    }

    private void getAllServiceRequest(String wsdlUrl, SRFilters srFilters, GeneralInfoTRVORowImpl generalInfoRow,
                                      int recordCount, int page, ArrayOfSortSpec sortSpec,
                                      Holder<ArrayOfServiceRequestLite> arrayOfSRLite,
                                      Holder<Integer> totalRecordCount, SessionHeader sessionHeader) {
        boolean isUserCountryRestricted =
            generalInfoRow.getCountryRestricted() != null && generalInfoRow.getCountryRestricted().booleanValue();

        //Added for US58- Japanese Platinum customer ability to view company SRs
        boolean isPlatinumUser =
            generalInfoRow.getPlatinumUser() != null && generalInfoRow.getPlatinumUser().booleanValue();


        java.util.Set<String> accountList = new java.util.HashSet<String>();

        //Modifed - US58- Japanese Platinum customer ability to view company SRs
        if (!isUserCountryRestricted || isPlatinumUser) {
            Array array = generalInfoRow.getActiveSiebelAccounts();
            if (array != null) {
                for (Object obj : array.getArray()) {
                    accountList.add((String)obj);
                }
            }
        }

        new EServiceLiteWSProxy().getAllCompanyServiceRequests(getWsWSDLUrl(),generalInfoRow.getLoginName(), srFilters, true, accountList,
                                                               recordCount, page, sortSpec, arrayOfSRLite,
                                                               totalRecordCount, sessionHeader);
    }

    private void getMyServiceRequest(String wsdlUrl, SRFilters srFilters, GeneralInfoTRVORowImpl generalInfoRow,
                                     int recordCount, int page, ArrayOfSortSpec sortSpec,
                                     Holder<ArrayOfServiceRequestLite> arrayOfSRLite, Holder<Integer> totalRecordCount,
                                     SessionHeader sessionHeader) {
        ArrayOfSiebelAccount siebelAccountList_banned = new ArrayOfSiebelAccount();
        java.util.List<SiebelAccount> accountList_banned = siebelAccountList_banned.getSiebelAccount();
        Array array = generalInfoRow.getBannedSiebelAccounts();
        if (array != null) {
            SiebelAccount account = null;
            for (Object obj : array.getArray()) {
                account = new SiebelAccount();
                account.setId((String)obj);
                accountList_banned.add(account);
            }
        }

        long tm = System.currentTimeMillis();

        new EServiceLiteWSProxy().getPersonalServiceRequests(wsdlUrl,srFilters, true, generalInfoRow.getContactId(),
                                                             siebelAccountList_banned, recordCount, page, sortSpec,
                                                             arrayOfSRLite, totalRecordCount, sessionHeader);
        logger.fine("setServiceRequestFileAttachment Execution took : " + (System.currentTimeMillis() - tm) +
                    " milliseconds.");

    }


    private void getTeamServiceRequest(String wsdlUrl, SRFilters srFilters, GeneralInfoTRVORowImpl generalInfoRow,
                                       int recordCount, int page, ArrayOfSortSpec sortSpec,
                                       Holder<ArrayOfServiceRequestLite> arrayOfSRLite,
                                       Holder<Integer> totalRecordCount, SessionHeader sessionHeader) {
        boolean isUserCountryRestricted =
            generalInfoRow.getCountryRestricted() != null && generalInfoRow.getCountryRestricted().booleanValue();

        //Added for US58- Japanese Platinum customer ability to view company SRs
        boolean isPlatinumUser =
            generalInfoRow.getPlatinumUser() != null && generalInfoRow.getPlatinumUser().booleanValue();
        java.util.Set<String> accountList = new java.util.HashSet<String>();
        //Modified for US58- Japanese Platinum customer ability to view company SRs
        if (!isUserCountryRestricted || isPlatinumUser) {
            accountList.add(generalInfoRow.getPrimaryAccountId());
        }

        new EServiceLiteWSProxy().getTeamServiceRequests(wsdlUrl, srFilters, generalInfoRow.getTeamName(), true,
                                                         accountList, recordCount, page, sortSpec, arrayOfSRLite,
                                                         totalRecordCount, sessionHeader);
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public void setSortSpec(SortSpec sortSpec) {
        this.sortSpec = sortSpec;
    }

    public SortSpec getSortSpec() {
        return sortSpec;
    }

    public void setSearchSpec(SRFilters searchSpec) {
        this.searchSpec = searchSpec;
    }

    public SRFilters getSearchSpec() {
        return searchSpec;
    }

    public void setWsWSDLUrl(String wsWSDLUrl) {
        this.wsWSDLUrl = wsWSDLUrl;
    }

    public String getWsWSDLUrl() {
        return wsWSDLUrl;
    }
}
