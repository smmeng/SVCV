package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.ArrayOfServiceRequestLite;
import com.mcafee.eservicelitews.ArrayOfSiebelAccount;
import com.mcafee.eservicelitews.ArrayOfSortSpec;
import com.mcafee.eservicelitews.servicerequest.SRFilters;
import com.mcafee.eservicelitews.servicerequest.ServiceRequestLite;
import com.mcafee.eservicelitews.servicerequest.SortSpec;
import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.eservicelitews.siebelaccount.SiebelAccount;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.xml.ws.Holder;

import mfe.spr.common.cache.SPRCoherenceCacheUtils;
import mfe.spr.model.queries.trans.GeneralInfoTRVORowImpl;
import mfe.spr.model.queries.trans.SearchSRTRVORowImpl;
import mfe.spr.model.services.SPRProductCatalogServiceImpl;
import mfe.spr.model.services.SPRServiceImpl;
import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.logging.ADFLogger;

import oracle.jbo.SortCriteria;
import oracle.jbo.domain.Array;

import org.apache.commons.lang.StringUtils;


public class SRData {
    private static final String className = SRData.class.getName();
    private static final ADFLogger logger =

        ADFLogger.createADFLogger(SRData.class);

    private static Map<String, String> sortSpecNameMapping = new HashMap<String, String>(5);
    static {
        sortSpecNameMapping.put("SRNumber", "createdField");
        sortSpecNameMapping.put("Status", "sPRStatusField");
        sortSpecNameMapping.put("subStatusCIS", "subStatusField");
        sortSpecNameMapping.put("ProductCIS", "mFEPointProductDescriptionField");
        sortSpecNameMapping.put("LastUpdated", "mFEPreviousInternalUpdateField");
        sortSpecNameMapping.put("Impact", "severityField");
        sortSpecNameMapping.put("SROwner", "requestorLoginField");
    }
    private Map<Integer, ServiceRequestLiteData> mData = new LinkedHashMap<Integer, ServiceRequestLiteData>();
    private int wsTotalRecordCount;
    private int fetchedSize;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private SortCriteria[] sortCriteria;
    private GeneralInfoTRVORowImpl generalInfoTRVORow;
    private SearchSRTRVORowImpl searchSRTRVORow;
    private int fetchSize;
    private String eServiceLiteWSDLURL;
    private boolean supportMer = false;
    private int rangeStartIndex;

    public SRData(String pEServiceLiteWSDLURL, SortCriteria[] pSortCriteria, GeneralInfoTRVORowImpl generalInfoRow,
                  SearchSRTRVORowImpl searchRow, int pFetchSize) {
        eServiceLiteWSDLURL = pEServiceLiteWSDLURL;
        sortCriteria = pSortCriteria;
        generalInfoTRVORow = generalInfoRow;
        searchSRTRVORow = searchRow;
        fetchSize = pFetchSize;
        if (null != searchRow && searchRow.getSupportMER() != null)
            supportMer = searchRow.getSupportMER();
        getNextResultSet(0);
    }

    private String getSortSpecName() {
        String name = "";
        if (sortCriteria != null && sortCriteria.length > 0) {
            name = sortSpecNameMapping.get(sortCriteria[0].getAttributeName());
        } else if (searchSRTRVORow != null && searchSRTRVORow.getSortedBy() != null &&
                   !StringUtils.isBlank(searchSRTRVORow.getSortedBy())) {
            name = sortSpecNameMapping.get(searchSRTRVORow.getSortedBy());
        } else {
            name = sortSpecNameMapping.get("SRNumber");
        }


        return name;
    }

    private String getSortOrder() {
        String order = "";

        if (sortCriteria != null && sortCriteria.length > 0) {
            if (!sortCriteria[0].isDescending()) {
                order = "ASC";
            } else {
                order = "DESC";
            }
        } else if (searchSRTRVORow != null && searchSRTRVORow.getOrderedBy() != null &&
                   !StringUtils.isBlank(searchSRTRVORow.getOrderedBy())) {
            order = searchSRTRVORow.getOrderedBy();
        } else {
            order = "DESC";
        }

        return order;
    }

    public void setFetchedSize(int size) {
        fetchedSize = size;
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(int count) {
        recordCount = count;
    }

    public void setResultSize(int size) {
        resultSize = size;
    }

    public int getResultSize() {
        return resultSize;
    }

    public void setResultIndex(int index) {
        resultIndex = index;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public void getNextResultSet(int position) {
        setResultIndex(position);

        // Get the query results.
        fetchData(position);
    }

    public boolean hasNext() {
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public ServiceRequestLite getNextSRData() {
        ServiceRequestLite sr = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {

            getNextResultSet(ri);
        }
        sr = mData.get(ri);
        setResultIndex(ri + 1);

        return sr;
    }

    private void fetchData(int position) {
        String methodName = "fetchData(int)";
        logger.info("FetchData Started ... position :: " + position);
        mData.clear();
        HashMap<String, Object> productsMap = SPRCoherenceCacheUtils.getSPRProductsCache();
        SPRServiceImpl appModule = (SPRServiceImpl)generalInfoTRVORow.getApplicationModule();
        SPRProductCatalogServiceImpl productCatalogModule =
            (SPRProductCatalogServiceImpl)appModule.getSPRProductCatalogService();
        productsMap = (HashMap<String, Object>)productCatalogModule.getAllProducts();


        if (searchSRTRVORow == null) {
            return;
        }

        int recordsToFetchCount = getFetchSize();
        int page = (position < recordsToFetchCount) ? 0 : (position / recordsToFetchCount);

        SRFilters srFilters = new SRFilters();
        if (searchSRTRVORow.getSearchByShowType()) {
            srFilters.setSRType(searchSRTRVORow.getShowType());
        }
        if (searchSRTRVORow.getSearchByStatus()) {
            srFilters.setStatus(searchSRTRVORow.getStatus() == null ? "" : searchSRTRVORow.getStatus());
        }
        if (searchSRTRVORow.getSearchBySubStatus()) {
            srFilters.setSubStatus(searchSRTRVORow.getSubStatus() == null ? "" : searchSRTRVORow.getSubStatus());
        }
        if (StringUtils.isNotEmpty(searchSRTRVORow.getProductCode())) {
            srFilters.setProduct(searchSRTRVORow.getProductCode());
        }

        ArrayOfSortSpec sortSpec = new ArrayOfSortSpec();
        SortSpec spec = new SortSpec();
        spec.setName(getSortSpecName());
        spec.setSortOrder(getSortOrder());
        logger.info("SortBy : " + getSortSpecName());
        logger.info("OrderBy: " + getSortOrder());
        spec.setSortSequence("1");
        sortSpec.getSortSpec().add(spec);
        
        // adding second level of sorting by Last Updated date and time
        spec = new SortSpec();
        spec.setName(sortSpecNameMapping.get("LastUpdated"));
        spec.setSortOrder("DESC");
        spec.setSortSequence("2");
        sortSpec.getSortSpec().add(spec);

        Holder<Integer> totalRecordCount = new Holder<Integer>();
        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(generalInfoTRVORow.getLoginName());
        Holder<ArrayOfServiceRequestLite> arrayOfSRLite = new Holder<ArrayOfServiceRequestLite>();

        // Fetch data
        int showType = searchSRTRVORow.getShowType();
        switch (showType) {
        case 0:
        case 2:
        case 4:
        case 6:
            getMyServiceRequest(eServiceLiteWSDLURL, srFilters, generalInfoTRVORow, recordsToFetchCount, page,
                                sortSpec, arrayOfSRLite, totalRecordCount, sessionHeader);
            break;
        case 1:
        case 3:
        case 5:
        case 7:
            getAllServiceRequest(eServiceLiteWSDLURL, srFilters, generalInfoTRVORow, recordsToFetchCount, page,
                                 sortSpec, arrayOfSRLite, totalRecordCount, sessionHeader);
            break;
        case 8:
        case 9:
        case 10:
        case 11:
            getTeamServiceRequest(eServiceLiteWSDLURL, srFilters, generalInfoTRVORow, recordsToFetchCount, page,
                                  sortSpec, arrayOfSRLite, totalRecordCount, sessionHeader);
            break;
        default:
            break;
        }

        // update the size variable
        if (totalRecordCount != null && totalRecordCount.value != null) {
            wsTotalRecordCount = totalRecordCount.value.intValue();
        } else {
            wsTotalRecordCount = 0;
        }

        if (arrayOfSRLite != null && arrayOfSRLite.value != null) {
            int startIndex = page * recordsToFetchCount;
            setResultIndex(startIndex);
            setRangeStartIndex(startIndex);
            List<ServiceRequestLite> srLiteList = arrayOfSRLite.value.getServiceRequestLite();
            ServiceRequestLiteData srLiteData = null;
            for (ServiceRequestLite srLite : srLiteList) {
                srLiteData = new ServiceRequestLiteData();
                srLiteData.setAbstract(srLite.getAbstract());
                srLiteData.setAccountId(srLite.getAccountId());
                srLiteData.setAvertID(srLite.getAvertID());
                srLiteData.setCreateDate(srLite.getCreateDate());
                srLiteData.setId(srLite.getId());
                srLiteData.setLastUpdated(srLite.getLastUpdated());
                srLiteData.setMFEContactEmail(srLite.getMFEContactEmail());
                srLiteData.setMFEPP(srLite.getMFEPP());
                srLiteData.setMFEPPDesc(srLite.getMFEPPDesc());
                srLiteData.setMFEPPVersion(srLite.getMFEPPVersion());
                srLiteData.setSRNum(srLite.getSRNum());
                srLiteData.setSROwner(srLite.getSROwner());
                srLiteData.setSeverity(srLite.getSeverity());
                srLiteData.setStatus(srLite.getStatus());
                srLiteData.setSPRStatus(srLite.getSPRStatus());
                srLiteData.setSubStatus(srLite.getSubStatus());
                if (productsMap.containsKey(srLite.getMFEPP())) {
                    srLiteData.setMfeeppDisplayName(((SprProduct)productsMap.get(srLite.getMFEPP())).getProdDisplayName());
                } else {
                    srLiteData.setMfeeppDisplayName(srLite.getMFEPPDesc());
                }
                mData.put(startIndex, srLiteData);
                if (logger.isFinest()) {
                    //                    logger.finest("Servcice Request :: " + srLite.getSRNum() +
                    //                                  " :: SROwner :: " + srLite.getSROwner() +
                    //                                  " :: LastUpdated :: " +
                    //                                  srLite.getLastUpdated() + " :: Id :: " +
                    //                                  srLite.getId() + " :: SRNum :: " +
                    //                                  srLite.getSRNum() + " :: MFEPP :: " +
                    //                                  srLite.getMFEPP() + " :: Abstract :: " +
                    //                                  srLite.getAbstract() + " :: CreateDate :: " +
                    //                                  srLite.getCreateDate() +
                    //                                  " :: MFEContactEmail :: " +
                    //                                  srLite.getMFEContactEmail() +
                    //                                  " :: Status :: " + srLite.getStatus() +
                    //                                  " :: SubStatus :: " + srLite.getSubStatus() +
                    //                                  " :: AvertID :: " + srLite.getAvertID());
                }
                ++startIndex;
            }
        }

        if (mData == null) {
            mData = new HashMap<Integer, ServiceRequestLiteData>(1);
            logger.logp(Level.INFO, className, methodName, "Service Request does not exist.");
        } else {
            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }

    }

    private void getMyServiceRequest(String wsdlUrl, SRFilters srFilters, GeneralInfoTRVORowImpl generalInfoRow,
                                     int recordCount, int page, ArrayOfSortSpec sortSpec,
                                     Holder<ArrayOfServiceRequestLite> arrayOfSRLite, Holder<Integer> totalRecordCount,
                                     SessionHeader sessionHeader) {
        ArrayOfSiebelAccount siebelAccountList_banned = new ArrayOfSiebelAccount();
        java.util.List<SiebelAccount> accountList_banned = siebelAccountList_banned.getSiebelAccount();
        Array array = generalInfoRow.getBannedSiebelAccounts();
        if (array != null) {
            SiebelAccount account = null;
            for (Object obj : array.getArray()) {
                account = new SiebelAccount();
                account.setId((String)obj);
                accountList_banned.add(account);
            }
        }

        long tm = System.currentTimeMillis();

        new EServiceLiteWSProxy().getPersonalServiceRequests(wsdlUrl, srFilters, false, generalInfoRow.getContactId(),
                                                             siebelAccountList_banned, recordCount, page, sortSpec,
                                                             arrayOfSRLite, totalRecordCount, sessionHeader);
        logger.fine("setServiceRequestFileAttachment Execution took : " + (System.currentTimeMillis() - tm) +
                    " milliseconds.");

    }


    private void getAllServiceRequest(String wsdlUrl, SRFilters srFilters, GeneralInfoTRVORowImpl generalInfoRow,
                                      int recordCount, int page, ArrayOfSortSpec sortSpec,
                                      Holder<ArrayOfServiceRequestLite> arrayOfSRLite,
                                      Holder<Integer> totalRecordCount, SessionHeader sessionHeader) {
        boolean isUserCountryRestricted =
            generalInfoRow.getCountryRestricted() != null && generalInfoRow.getCountryRestricted().booleanValue();

        //Added for US58- Japanese Platinum customer ability to view company SRs
        boolean isPlatinumUser =
            generalInfoRow.getPlatinumUser() != null && generalInfoRow.getPlatinumUser().booleanValue();
        java.util.Set<String> accountList = new java.util.HashSet<String>();

        //Modified for US58- Japanese Platinum customer ability to view company SRs
        if (!isUserCountryRestricted || isPlatinumUser) {
            Array array = generalInfoRow.getActiveSiebelAccounts();
            if (array != null) {
                for (Object obj : array.getArray()) {
                    accountList.add((String)obj);
                }
            }
        }

        new EServiceLiteWSProxy().getAllCompanyServiceRequests(wsdlUrl,generalInfoRow.getLoginName(), srFilters, isSupportMer(), accountList,
                                                               recordCount, page, sortSpec, arrayOfSRLite,
                                                               totalRecordCount, sessionHeader);
    }

    public void setSortCriteria(SortCriteria[] pSortCriteria) {
        sortCriteria = pSortCriteria;
    }

    public SortCriteria[] getSortCriteria() {
        return sortCriteria;
    }

    public void setGeneralInfoTRVORow(GeneralInfoTRVORowImpl generalInfoTRVORow) {
        this.generalInfoTRVORow = generalInfoTRVORow;
    }

    public GeneralInfoTRVORowImpl getGeneralInfoTRVORow() {
        return generalInfoTRVORow;
    }

    public void setSearchSRTRVORow(SearchSRTRVORowImpl searchSRTRVORow) {
        this.searchSRTRVORow = searchSRTRVORow;
    }

    public SearchSRTRVORowImpl getSearchSRTRVORow() {
        return searchSRTRVORow;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public List<ServiceRequestLite> fetchAllRecords() {

        SRFilters srFilters = new SRFilters();
        if (searchSRTRVORow.getSearchByShowType()) {
            srFilters.setSRType(searchSRTRVORow.getShowType());
        }
        if (searchSRTRVORow.getSearchByStatus()) {
            srFilters.setStatus(searchSRTRVORow.getStatus() == null ? "" : searchSRTRVORow.getStatus());
        }
        if (searchSRTRVORow.getSearchBySubStatus()) {
            srFilters.setSubStatus(searchSRTRVORow.getSubStatus() == null ? "" : searchSRTRVORow.getSubStatus());
        }
        if (searchSRTRVORow.getSearchByProduct()) {
            srFilters.setProduct(searchSRTRVORow.getProductCode() == null ? "" : searchSRTRVORow.getProductCode());
        }

        ArrayOfSortSpec sortSpec = new ArrayOfSortSpec();
        SortSpec spec = new SortSpec();
        spec.setName(getSortSpecName());
        spec.setSortOrder(getSortOrder());
        spec.setSortSequence("1");
        sortSpec.getSortSpec().add(spec);

        Holder<Integer> totalRecordCount = new Holder<Integer>();
        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(generalInfoTRVORow.getLoginName());
        Holder<ArrayOfServiceRequestLite> arrayOfSRLite = new Holder<ArrayOfServiceRequestLite>();

        // Fetch data
        int showType = searchSRTRVORow.getShowType();
        int page = 0, totalCount = 0, fetchCount = 100;
        List<ServiceRequestLite> srList = new LinkedList<ServiceRequestLite>();
        do {
            switch (showType) {
            case 0:
            case 2:
            case 4:
            case 6:
                getMyServiceRequest(eServiceLiteWSDLURL, srFilters, generalInfoTRVORow, fetchCount, page, sortSpec,
                                    arrayOfSRLite, totalRecordCount, sessionHeader);
                break;
            case 1:
            case 3:
            case 5:
            case 7:
                getAllServiceRequest(eServiceLiteWSDLURL, srFilters, generalInfoTRVORow, fetchCount, page, sortSpec,
                                     arrayOfSRLite, totalRecordCount, sessionHeader);
                break;
            case 8:
            case 9:
            case 10:
            case 11:
                getTeamServiceRequest(eServiceLiteWSDLURL, srFilters, generalInfoTRVORow, fetchCount, page, sortSpec,
                                      arrayOfSRLite, totalRecordCount, sessionHeader);
                break;
            default:
                break;
            }

            // update the size variable
            if (page == 0 && totalRecordCount != null && totalRecordCount.value != null) {
                totalCount = totalRecordCount.value.intValue();
            }

            if (arrayOfSRLite != null && arrayOfSRLite.value != null) {
                srList.addAll(arrayOfSRLite.value.getServiceRequestLite());
            }

            if (srList.size() < totalCount) {
                if ((totalCount - srList.size()) < fetchSize) {
                    fetchCount = totalCount - srList.size();
                }
                ++page;
            } else {
                page = -1;
            }
        } while (page != -1);

        return srList;
    }

    public void setSupportMer(boolean supportMer) {
        this.supportMer = supportMer;
    }

    public boolean isSupportMer() {
        return supportMer;
    }

    private void getTeamServiceRequest(String wsdlUrl, SRFilters srFilters, GeneralInfoTRVORowImpl generalInfoRow,
                                       int recordCount, int page, ArrayOfSortSpec sortSpec,
                                       Holder<ArrayOfServiceRequestLite> arrayOfSRLite,
                                       Holder<Integer> totalRecordCount, SessionHeader sessionHeader) {
        boolean isUserCountryRestricted =
            generalInfoRow.getCountryRestricted() != null && generalInfoRow.getCountryRestricted().booleanValue();
        boolean isPlatinumUser =
            generalInfoRow.getPlatinumUser() != null && generalInfoRow.getPlatinumUser().booleanValue();

        java.util.Set<String> accountList = new java.util.HashSet<String>();
        if (!isUserCountryRestricted || isPlatinumUser) {
            accountList.add(generalInfoRow.getPrimaryAccountId());
        }

        new EServiceLiteWSProxy().getTeamServiceRequests(wsdlUrl, srFilters, generalInfoTRVORow.getTeamName(),
                                                         isSupportMer(), accountList, recordCount, page, sortSpec,
                                                         arrayOfSRLite, totalRecordCount, sessionHeader);
    }


}
