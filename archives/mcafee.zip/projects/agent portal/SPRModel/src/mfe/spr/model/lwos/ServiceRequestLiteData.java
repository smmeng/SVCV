package mfe.spr.model.lwos;

import com.mcafee.eservicelitews.servicerequest.ServiceRequestLite;

public class ServiceRequestLiteData extends ServiceRequestLite {


    private String mfeeppDisplayName;

    /**
     * Sets the value of the displayName property.
     *
     * @param mfeeppDisplayName
     * allowed object is
     * {@link String}
     *
     */
    public void setMfeeppDisplayName(String mfeeppDisplayName) {
        this.mfeeppDisplayName = mfeeppDisplayName;
    }

    /**
     * Gets the value of the displayName property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMfeeppDisplayName() {
        return mfeeppDisplayName;
    }
}
