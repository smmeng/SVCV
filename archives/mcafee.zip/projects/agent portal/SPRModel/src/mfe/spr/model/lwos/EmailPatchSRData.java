package mfe.spr.model.lwos;

import java.io.Serializable;

import java.util.Date;


public class EmailPatchSRData implements Serializable {

    @SuppressWarnings("compatibility:-8495280655618781659")
    private static final long serialVersionUID = 1L;

    public EmailPatchSRData() {
        super();
    }

    protected String firstName;

    protected String lastName;

    protected String contactEmail;

    protected String status;

    protected String subStatus;

    protected String id;

    protected String srNum;

    protected String mfepp;

    protected String mfeppDesc;

    protected String mfeppVersion;

    protected String _abstract;

    protected Date createDate;

    protected String contactPrefLanguage;

    /**
     * Gets the value of the firstName property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the contactEmail property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getContactEmail() {
        return contactEmail;
    }

    /**
     * Sets the value of the contactEmail property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setContactEmail(String value) {
        this.contactEmail = value;
    }

    /**
     * Gets the value of the status property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the subStatus property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getSubStatus() {
        return subStatus;
    }

    /**
     * Sets the value of the subStatus property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setSubStatus(String value) {
        this.subStatus = value;
    }

    /**
     * Gets the value of the id property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the srNum property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getSRNum() {
        return srNum;
    }

    /**
     * Sets the value of the srNum property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setSRNum(String value) {
        this.srNum = value;
    }

    /**
     * Gets the value of the mfepp property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMFEPP() {
        return mfepp;
    }

    /**
     * Sets the value of the mfepp property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMFEPP(String value) {
        this.mfepp = value;
    }

    /**
     * Gets the value of the mfeppDesc property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMFEPPDesc() {
        return mfeppDesc;
    }

    /**
     * Sets the value of the mfeppDesc property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMFEPPDesc(String value) {
        this.mfeppDesc = value;
    }

    /**
     * Gets the value of the mfeppVersion property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMFEPPVersion() {
        return mfeppVersion;
    }

    /**
     * Sets the value of the mfeppVersion property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMFEPPVersion(String value) {
        this.mfeppVersion = value;
    }

    /**
     * Gets the value of the abstract property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getAbstract() {
        return _abstract;
    }

    /**
     * Sets the value of the abstract property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setAbstract(String value) {
        this._abstract = value;
    }

    /**
     * Gets the value of the createDate property.
     *
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     *
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *
     */
    public void setCreateDate(Date value) {
        this.createDate = value;
    }

    /**
     * Gets the value of the contactPrefLanguage property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getContactPrefLanguage() {
        return contactPrefLanguage;
    }

    /**
     * Sets the value of the contactPrefLanguage property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setContactPrefLanguage(String value) {
        this.contactPrefLanguage = value;
    }


}
