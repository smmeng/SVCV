package mfe.spr.model.lwos;


import com.mcafee.eservicelitews.sessionheader.SessionHeader;
import com.mcafee.platinumportalws.productprofile.ProductProfile;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;

import mfe.spr.model.services.SPRProductCatalogServiceImpl;
import mfe.spr.model.wrapper.ProductProfileWrapper;
import mfe.spr.proxy.elite.EServiceLiteWSProxy;

import oracle.adf.share.ADFContext;
import oracle.adf.share.logging.ADFLogger;


public class ProductProfileData {

    private static final String className = ProductProfileData.class.getName();
    private static final ADFLogger logger = ADFLogger.createADFLogger(ProductProfileData.class);
    private Map<Integer, ProductProfileWrapper> mData = new HashMap<Integer, ProductProfileWrapper>();
    private Map<String, String> productDescMap = new HashMap<String, String>();

    private int fetchedSize;
    private int wsTotalRecordCount;
    private int recordCount;
    private int resultSize;
    private int resultIndex;
    private String sessionLogin;
    private int fetchSize;
    private String wsdlURL;
    private int rangeStartIndex;
    private boolean platinumUser;
    private String productRowId;
    private String productVersion;
    SPRProductCatalogServiceImpl productCatalogModule;

    public ProductProfileData(SPRProductCatalogServiceImpl productCatalogModule, String wsdl, String sessionLogin,
                              boolean platinumUser, String productRowid, String productVersion) {
        this.wsdlURL = wsdl;
        this.sessionLogin = sessionLogin;
        this.platinumUser = platinumUser;
        this.productRowId = productRowid;
        this.productVersion = productVersion;
        this.productCatalogModule = productCatalogModule;
        getNextResultSet(0);
    }

    public int getFetchedSize() {
        return fetchedSize;
    }

    public int getWsTotalRecordCount() {
        return wsTotalRecordCount;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public int getResultSize() {
        return resultSize;
    }

    public int getResultIndex() {
        return resultIndex;
    }

    public String getSessionLogin() {
        return sessionLogin;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public String getWsdlURL() {
        return wsdlURL;
    }

    public int getRangeStartIndex() {
        return rangeStartIndex;
    }

    public void setRangeStartIndex(int rangeStartIndex) {
        this.rangeStartIndex = rangeStartIndex;
    }

    public void setFetchedSize(int fetchedSize) {
        this.fetchedSize = fetchedSize;
    }

    public void setRecordCount(int recordCount) {
        this.recordCount = recordCount;
    }

    public void setResultIndex(int resultIndex) {
        this.resultIndex = resultIndex;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public void getNextResultSet(int position) {
        setResultIndex(position);

        // Get the query results.
        fetchData(position);
    }

    public ProductProfileWrapper getNextData() {
        ProductProfileWrapper productProfileWrapper = null;
        int ri = getResultIndex();
        if (!mData.containsKey(ri)) {
            getNextResultSet(ri);
        }
        productProfileWrapper = mData.get(ri);
        setResultIndex(ri + 1);

        return productProfileWrapper;
    }


    private void fetchData(int position) {
        String methodName = "fetchData(int)";
        logger.logp(Level.INFO, className, methodName, position + "");
        mData.clear();
        wsTotalRecordCount = 0;

        SessionHeader sessionHeader = new SessionHeader();
        sessionHeader.setSiebelUserName(getSessionLogin());

        StringBuffer searchSpec = new StringBuffer("(");
        if (isPlatinumUser()) {
            searchSpec.append("[MFE Account Environment Profile.MFE Profile Owner] IS NULL OR ");
        }

        searchSpec.append("[MFE Account Environment Profile.MFE Profile Owner]~='");
        searchSpec.append(ADFContext.getCurrent().getSecurityContext().getUserName().toUpperCase());
        searchSpec.append("')");

        if (getProductRowId() != null) {
            searchSpec.append(" AND ");
            searchSpec.append("[MFE Account Environment Profile.Point Product Id]='");
            searchSpec.append(getProductRowId());
            searchSpec.append("'");
        }
        if (getProductVersion() != null) {
            searchSpec.append(" AND ");
            searchSpec.append("([MFE Account Environment Profile.Product Version]='");
            searchSpec.append(getProductVersion());
            searchSpec.append("' OR [MFE Account Environment Profile.Product Version]='')");
        }

        List<ProductProfile> listProductProfiles =
            new EServiceLiteWSProxy().getProductProfiles(wsdlURL, searchSpec.toString(), sessionHeader);

        if (listProductProfiles != null) {
            wsTotalRecordCount = listProductProfiles.size();

            int i = 0;
            Set<String> productRowIdSet = new HashSet<String>();
            for (ProductProfile productProfile : listProductProfiles) {

                ProductProfileWrapper productProfileWrapper = new ProductProfileWrapper();
                mData.put(i, productProfileWrapper.copyProductProfileToWrapper(productProfile));
                productRowIdSet.add(productProfile.getPointProductId());
                i++;
            }

            productDescMap = productCatalogModule.getProductDisplayName(productRowIdSet);

            recordCount = mData.size();
            setFetchedSize(getFetchedSize() + mData.size());
            setResultSize(mData.size());
        }

        logger.exiting(className, methodName);

    }

    public void setResultSize(int resultSize) {
        this.resultSize = resultSize;
    }

    public boolean hasNext() {
        if (resultIndex < wsTotalRecordCount) {
            return true;
        }
        return false;
    }

    public void setPlatinumUser(boolean platinumUser) {
        this.platinumUser = platinumUser;
    }

    public boolean isPlatinumUser() {
        return platinumUser;
    }

    public void setProductRowId(String productRowId) {
        this.productRowId = productRowId;
    }

    public String getProductRowId() {
        return productRowId;
    }

    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    public String getProductVersion() {
        return productVersion;
    }

    public void setProductDescMap(Map<String, String> productDescMap) {
        this.productDescMap = productDescMap;
    }

    public Map<String, String> getProductDescMap() {
        return productDescMap;
    }

}
